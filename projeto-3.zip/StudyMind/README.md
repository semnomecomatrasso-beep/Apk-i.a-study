# StudyMind AI

Plataforma de estudos com inteligência artificial real: resolve atividades por foto, cria provas com correção automática, tem chat, resumos com mapa mental e professor particular. Funciona no celular e no computador.

- **Backend:** Node.js + Express, banco SQLite (arquivo), autenticação por cookie seguro.
- **Frontend:** site em JavaScript puro (sem etapa de build), tema escuro com azul, roxo e branco.
- **IA:** API da Anthropic (Claude), sempre chamada pelo servidor. A chave nunca vai para o navegador.
- **Nada é simulado:** se a IA, o e-mail, o Google ou o pagamento não estiverem configurados, o site mostra uma mensagem clara dizendo o que falta.

## O que já funciona

| Área | O que faz |
|---|---|
| Resolver atividades | Foto pela câmera ou imagem enviada, resolução passo a passo. A foto não é guardada; só o texto da resolução. |
| Criar provas | Matéria, assunto, dificuldade, nível e quantidade (1 a 20). Prova inédita, correção automática no servidor, nota, explicação de cada questão e histórico de tentativas. |
| Chat inteligente | Conversas com histórico salvo. |
| Resumos | Resumo, pontos importantes, mapa mental em texto, termos-chave e perguntas de revisão. Aceita texto colado ou arquivo .txt. |
| Professor particular | Aulas por assunto, com nível (iniciante a avançado) e estilo ajustáveis durante a conversa, exemplos e exercícios. |
| Conta | Cadastro, login, recuperação de senha, perfil, matérias favoritas, trocar senha e apagar conta. |
| Histórico | Conversas, atividades, provas e resumos, com filtro e opção de apagar. |
| Planos | Gratuito e Premium, limites diários por ferramenta e preços configuráveis. |
| Limites | Limite diário por plano e por ferramenta, mais limite de requisições por minuto. |

## Requisitos

- Node.js 20 ou mais novo
- Uma chave de API da Anthropic (para as ferramentas de IA)

## Instalação local

```bash
npm install
cp .env.example .env     # no Windows: copy .env.example .env
# edite o .env (veja abaixo)
npm start
```

Abra http://localhost:3000.

Em desenvolvimento, o servidor funciona mesmo sem `JWT_SECRET` (ele cria um segredo temporário e as sessões caem ao reiniciar). Em produção o `JWT_SECRET` é obrigatório.

## Configuração (.env)

### Obrigatório

| Variável | Para quê |
|---|---|
| `JWT_SECRET` | Segredo das sessões, com pelo menos 32 caracteres. Gere com `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `ANTHROPIC_API_KEY` | Chave da IA. Crie em https://console.anthropic.com/. Sem ela, o site abre e mostra o aviso "IA ainda não configurada". |
| `BASE_URL` | Endereço público do site (ex.: `https://meusite.com`). Usado em links de e-mail, login Google e pagamento. |

### Opcional

- **`AI_MODEL`**: modelo usado (padrão `claude-sonnet-5-5`). Se a Anthropic mudar os nomes, ajuste aqui.
- **`AI_MAX_IMAGE_MB`**: tamanho máximo da foto (padrão 5).
- **E-mail (`SMTP_*`)**: necessário para "Esqueci minha senha" em produção. Use o SMTP de qualquer provedor (Brevo, Mailgun, Amazon SES, Gmail com senha de app...). Em desenvolvimento, sem SMTP, o link de recuperação aparece no console do servidor.
- **Login com Google (`GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET`)**: crie uma credencial "ID do cliente OAuth" no Google Cloud e cadastre como URI de redirecionamento `BASE_URL/api/auth/google/callback`. O botão só aparece se estiver configurado.
- **Preços (`PRICE_*`)**: valores exibidos na página de planos.
- **Pagamentos (`STRIPE_*`)**: veja a seção abaixo.
- **Limites (`LIMIT_FREE_*` e `LIMIT_PREMIUM_*`)**: trocam os limites diários. Padrões: gratuito = chat 20, atividades 5, provas 3, resumos 5, professor 20; premium = 300, 60, 30, 60, 300.
- **`TRUST_PROXY=1`**: use quando o site ficar atrás de proxy (Render, Railway, Nginx...).

## Pagamentos (Stripe)

Não existe nenhuma compra simulada. Sem a configuração abaixo, o botão de assinar fica desativado e a página explica por quê.

1. Crie uma conta no Stripe e, no painel, um **produto Premium** com preço recorrente mensal e/ou anual.
2. Copie os IDs dos preços (`price_...`) para `STRIPE_PRICE_MONTHLY` e `STRIPE_PRICE_YEARLY`.
3. Coloque a chave secreta em `STRIPE_SECRET_KEY`.
4. Crie um **webhook** apontando para `BASE_URL/api/billing/webhook` com os eventos `checkout.session.completed`, `customer.subscription.updated` e `customer.subscription.deleted`. Copie o segredo do webhook para `STRIPE_WEBHOOK_SECRET`.
5. Informe em `PRICE_PREMIUM_MONTHLY` e `PRICE_PREMIUM_YEARLY` os valores que aparecem na página de planos (devem bater com os do Stripe).
6. Teste primeiro com as chaves de teste do Stripe.

O plano Premium é ativado e desativado pelo webhook, e o botão "Gerenciar assinatura" abre o portal do cliente do Stripe.

## Publicar na internet

O servidor precisa rodar o tempo todo e guardar o arquivo do banco em disco que **não seja apagado**.

**Com Docker** (qualquer VPS, Fly.io, Railway, Render):

```bash
docker build -t studymind .
docker run -d -p 3000:3000 --env-file .env -v studymind-data:/data studymind
```

O banco fica em `/data/studymind.db`. Monte um volume ou disco persistente nesse caminho.

**Sem Docker** (VPS): instale o Node 20, rode `npm install --omit=dev`, defina `NODE_ENV=production` e mantenha o processo com `pm2` ou `systemd`. Coloque o Nginx ou Caddy na frente para ter HTTPS e use `TRUST_PROXY=1`.

Use sempre **HTTPS** em produção (o cookie de sessão só é marcado como `Secure` quando `BASE_URL` começa com `https://`).

## Estrutura

```
src/
  server.js         servidor Express e segurança (helmet, limites, erros)
  config.js         leitura do .env
  db.js             banco SQLite e tabelas
  ai.js             chamadas à API de IA
  usage.js          limites diários
  prompts.js        instruções dadas à IA
  middleware.js     sessão, CSRF, limites de requisições
  mailer.js         envio de e-mail
  lib/              funções puras (JSON, planos, usuário)
  routes/           auth, profile, chat, tutor, solve, exams, summaries,
                    history, conversations, billing
public/             site (HTML, CSS e módulos JavaScript)
test/               testes automáticos
```

## Endpoints principais

| Método e rota | Função |
|---|---|
| `POST /api/auth/register`, `/login`, `/logout`, `/forgot`, `/reset` | Conta |
| `GET /api/auth/google` | Login com Google (se configurado) |
| `POST /api/chat` | Chat |
| `POST /api/tutor` | Professor particular |
| `POST /api/solve` | Resolver atividade por imagem |
| `POST /api/exams`, `POST /api/exams/:id/submit` | Gerar prova e corrigir |
| `POST /api/summaries` | Resumos |
| `GET /api/history`, `/api/usage`, `/api/plans`, `/api/config` | Histórico, uso, planos e estado da configuração |
| `POST /api/billing/checkout`, `/portal`, `/webhook` | Assinaturas (Stripe) |

## Segurança

- Senhas com bcrypt; sessão em cookie `HttpOnly` + `SameSite=Lax` (e `Secure` em HTTPS).
- Proteção contra CSRF por cabeçalho obrigatório nas requisições que alteram dados.
- Validação de todos os dados de entrada (zod), limite de tamanho de textos e imagens.
- Limite de requisições por IP e por usuário; limite diário de uso por plano.
- Cabeçalhos de segurança e Content-Security-Policy (helmet).
- Respostas da IA são exibidas com escape de HTML.
- A chave da IA e as chaves de pagamento ficam só no servidor.

## Testes

```bash
npm run check   # confere a sintaxe de todos os arquivos
npm test        # testes automáticos das funções puras
```

O arquivo `.github/workflows/build.yml` (ou o `build.yml` entregue junto) roda essas verificações e testa a construção da imagem Docker.

## Limitações conhecidas (leia antes de publicar)

- Este projeto foi escrito e verificado por análise de sintaxe e testes das funções puras. **Os fluxos que dependem de serviços externos (IA, Google, Stripe, SMTP) não puderam ser testados com contas reais.** Teste cada um com suas credenciais antes de abrir para o público, os pagamentos primeiro no modo de teste do Stripe.
- SQLite funciona bem para um servidor só. Para várias instâncias ou muito tráfego, migre para PostgreSQL.
- A IA pode errar. O site avisa o estudante para conferir o conteúdo importante.
- O contador diário zera à meia-noite no fuso de `TIMEZONE` (padrão `America/Sao_Paulo`).
- Não há painel de administração; limites e preços são trocados no `.env`.
- Resumos aceitam texto e arquivos `.txt`. PDFs precisam ser copiados como texto.
