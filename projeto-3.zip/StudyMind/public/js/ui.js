// Peças de interface compartilhadas: criador de elementos, ícones, Markdown seguro, avisos.

export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}

const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  upload: '<path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 20h16"/>',
  exam: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  summary: '<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2z"/><path d="M8 7h7M8 11h7"/>',
  tutor: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/>',
  history: '<path d="M3 12a9 9 0 109-9 9 9 0 00-7 3.5"/><path d="M3 4v4h4"/><path d="M12 8v5l3 2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
  logout: '<path d="M9 4H5v16h4"/><path d="M16 8l4 4-4 4"/><path d="M20 12H9"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  send: '<path d="M3 11l18-8-8 18-2-8z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V6a2 2 0 012-2h10"/>',
  download: '<path d="M12 4v12"/><path d="M7 11l5 5 5-5"/><path d="M4 20h16"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  sparkle: '<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  more: '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'
};

export function icon(name, size = 20) {
  const span = document.createElement('span');
  span.className = 'icon';
  span.innerHTML = `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
  return span;
}

export const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function inline(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
  return s;
}

// Markdown simples e seguro: todo o texto é escapado antes de virar HTML.
export function md(src) {
  const lines = String(src || '').replace(/\r/g, '').split('\n');
  let out = '';
  let list = null;
  let code = false;
  let codeBuf = [];
  let para = [];
  const flushPara = () => {
    if (para.length) {
      out += '<p>' + para.map(inline).join('<br>') + '</p>';
      para = [];
    }
  };
  const closeList = () => {
    if (list) {
      out += `</${list}>`;
      list = null;
    }
  };
  for (const raw of lines) {
    if (raw.trim().startsWith('```')) {
      if (code) {
        out += '<pre><code>' + esc(codeBuf.join('\n')) + '</code></pre>';
        codeBuf = [];
        code = false;
      } else {
        flushPara();
        closeList();
        code = true;
      }
      continue;
    }
    if (code) {
      codeBuf.push(raw);
      continue;
    }
    const line = raw.trimEnd();
    let m;
    if (!line.trim()) {
      flushPara();
      closeList();
    } else if ((m = line.match(/^(#{1,4})\s+(.*)$/))) {
      flushPara();
      closeList();
      const lvl = Math.min(m[1].length + 1, 5);
      out += `<h${lvl}>${inline(m[2])}</h${lvl}>`;
    } else if ((m = line.match(/^\s*[-*•]\s+(.*)$/))) {
      flushPara();
      if (list !== 'ul') {
        closeList();
        out += '<ul>';
        list = 'ul';
      }
      out += `<li>${inline(m[1])}</li>`;
    } else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
      flushPara();
      if (list !== 'ol') {
        closeList();
        out += '<ol>';
        list = 'ol';
      }
      out += `<li>${inline(m[1])}</li>`;
    } else if (/^---+$/.test(line.trim())) {
      flushPara();
      closeList();
      out += '<hr>';
    } else {
      closeList();
      para.push(line);
    }
  }
  if (code) out += '<pre><code>' + esc(codeBuf.join('\n')) + '</code></pre>';
  flushPara();
  closeList();
  return out;
}

export function mdBox(text, cls = '') {
  return h('div', { class: 'md ' + cls, html: md(text) });
}

export function toast(msg, type = 'info') {
  const box = document.getElementById('toasts');
  const el = h('div', { class: 'toast ' + type }, msg);
  box.append(el);
  setTimeout(() => el.classList.add('out'), 4200);
  setTimeout(() => el.remove(), 4700);
}

export function fmtDate(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

export function pageHeader(title, subtitle, iconName) {
  return h(
    'header',
    { class: 'page-head' },
    h('div', { class: 'page-icon' }, icon(iconName || 'sparkle', 26)),
    h('div', {}, h('h1', {}, title), subtitle ? h('p', { class: 'muted' }, subtitle) : null)
  );
}

export function banner(type, ...content) {
  return h('div', { class: 'banner ' + type }, icon(type === 'info' ? 'sparkle' : 'alert', 20), h('div', {}, content));
}

export function aiBanner(state) {
  if (state.config && !state.config.aiConfigured) {
    return banner(
      'warn',
      h('strong', {}, 'A IA ainda não está configurada neste servidor. '),
      'Falta definir a variável ',
      h('code', {}, 'ANTHROPIC_API_KEY'),
      ' no arquivo ',
      h('code', {}, '.env'),
      ' e reiniciar o servidor (veja o README). Enquanto isso, as ferramentas de IA vão mostrar este aviso.'
    );
  }
  return null;
}

export function spinner(text) {
  return h('div', { class: 'loading-box' }, h('div', { class: 'spinner' }), text ? h('p', {}, text) : null);
}

export async function withBusy(btn, fn) {
  if (btn.disabled) return undefined;
  btn.disabled = true;
  btn.classList.add('loading');
  try {
    return await fn();
  } finally {
    btn.disabled = false;
    btn.classList.remove('loading');
  }
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('Copiado!', 'ok');
  } catch {
    toast('Não foi possível copiar. Selecione o texto e copie manualmente.', 'error');
  }
}

export function downloadText(filename, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
  const a = h('a', { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const SUBJECTS = [
  'Matemática', 'Português', 'Redação', 'Literatura', 'Física', 'Química', 'Biologia',
  'História', 'Geografia', 'Inglês', 'Espanhol', 'Filosofia', 'Sociologia', 'Artes', 'Informática'
];
export const SCHOOL_LEVELS = ['Ensino fundamental I', 'Ensino fundamental II', 'Ensino médio', 'Vestibular / ENEM', 'Ensino superior'];

export function field(label, control, hint) {
  return h('label', { class: 'field' }, h('span', { class: 'label' }, label), control, hint ? h('small', { class: 'muted' }, hint) : null);
}

export function select(options, value, props = {}) {
  const el = h('select', { class: 'input', ...props }, options.map(([v, t]) => h('option', { value: v }, t)));
  el.value = value;
  return el;
}
