import { h, icon, toast, withBusy, aiBanner, pageHeader, mdBox, copyText, downloadText, field, spinner, fmtDate } from '../ui.js';
import { api } from '../api.js';
import { go } from '../state.js';

function treeText(m) {
  const lines = ['🧠 ' + m.centro];
  m.ramos.forEach((r, i) => {
    const lastR = i === m.ramos.length - 1;
    lines.push((lastR ? '└── ' : '├── ') + r.nome);
    (r.itens || []).forEach((it, j) => {
      const lastI = j === r.itens.length - 1;
      lines.push((lastR ? '    ' : '│   ') + (lastI ? '└── ' : '├── ') + it);
    });
  });
  return lines.join('\n');
}

function plainText(title, d) {
  return [
    title,
    '',
    'RESUMO',
    d.resumo,
    '',
    'PONTOS IMPORTANTES',
    ...d.pontos_importantes.map((p) => '- ' + p),
    '',
    'MAPA MENTAL',
    treeText(d.mapa_mental),
    '',
    'TERMOS-CHAVE',
    ...(d.termos_chave || []).map((t) => `- ${t.termo}: ${t.definicao}`),
    '',
    'PERGUNTAS DE REVISÃO',
    ...(d.perguntas_revisao || []).map((q, i) => `${i + 1}. ${q}`)
  ].join('\n');
}

function renderResult(title, d) {
  const txt = plainText(title, d);
  return h(
    'div',
    { class: 'result-stack' },
    h('div', { class: 'card' }, h('h2', {}, title), h('h3', {}, 'Resumo'), mdBox(d.resumo)),
    h('div', { class: 'card' }, h('h3', {}, 'Pontos mais importantes'), h('ul', { class: 'check-list' }, d.pontos_importantes.map((p) => h('li', {}, icon('check', 16), h('span', {}, p))))),
    h('div', { class: 'card' }, h('h3', {}, 'Mapa mental'), h('pre', { class: 'tree' }, treeText(d.mapa_mental))),
    (d.termos_chave || []).length ? h('div', { class: 'card' }, h('h3', {}, 'Termos-chave'), h('dl', { class: 'terms' }, d.termos_chave.map((t) => [h('dt', {}, t.termo), h('dd', {}, t.definicao)]))) : null,
    (d.perguntas_revisao || []).length ? h('div', { class: 'card' }, h('h3', {}, 'Perguntas de revisão'), h('ol', {}, d.perguntas_revisao.map((q) => h('li', {}, q)))) : null,
    h('div', { class: 'row wrap' }, h('button', { class: 'btn ghost', onclick: () => copyText(txt) }, icon('copy'), 'Copiar tudo'), h('button', { class: 'btn ghost', onclick: () => downloadText('resumo.txt', txt) }, icon('download'), 'Baixar .txt'), h('a', { class: 'btn primary', href: '#/summary' }, icon('plus'), 'Novo resumo'))
  );
}

async function detail(id) {
  const r = await api('/summaries/' + id);
  return h('div', { class: 'page' }, pageHeader('Resumo salvo', fmtDate(r.createdAt), 'summary'), r.data ? renderResult(r.title, r.data) : h('div', { class: 'banner error' }, 'Este resumo não pôde ser lido.'));
}

export async function summaryView(ctx) {
  if (ctx.params.id) return detail(ctx.params.id);

  const title = h('input', { class: 'input', maxlength: '120', placeholder: 'Título (opcional)' });
  const text = h('textarea', { class: 'input', rows: '9', maxlength: '30000', placeholder: 'Cole aqui o texto, a matéria ou suas anotações…' });
  const counter = h('small', { class: 'muted' }, '0 / 30.000 caracteres');
  text.addEventListener('input', () => (counter.textContent = `${text.value.length.toLocaleString('pt-BR')} / 30.000 caracteres`));
  const fileInput = h('input', {
    type: 'file',
    accept: '.txt,.md,text/plain',
    hidden: true,
    onchange: async (e) => {
      const f = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!f) return;
      if (f.size > 200 * 1024) return toast('Arquivo grande demais. Use um .txt de até 200 KB.', 'error');
      text.value = (await f.text()).slice(0, 30000);
      text.dispatchEvent(new Event('input'));
      if (!title.value) title.value = f.name.replace(/\.[^.]+$/, '');
    }
  });
  const result = h('div');
  const btn = h('button', { class: 'btn primary block', type: 'button' }, icon('sparkle'), 'Resumir com IA');

  btn.addEventListener('click', () => {
    if (text.value.trim().length < 80) return toast('Cole um texto maior (mínimo de 80 caracteres).', 'error');
    withBusy(btn, async () => {
      result.replaceChildren(spinner('A IA está organizando o conteúdo…'));
      try {
        const r = await api('/summaries', { method: 'POST', body: { title: title.value.trim() || undefined, text: text.value } });
        result.replaceChildren(renderResult(r.title, r.data));
        loadList();
      } catch (err) {
        result.replaceChildren(h('div', { class: 'banner error' }, icon('alert'), h('div', {}, err.message)));
      }
    });
  });

  const listBox = h('div', { class: 'card' }, h('h3', {}, 'Resumos salvos'), h('p', { class: 'muted' }, 'Carregando…'));
  function loadList() {
    api('/summaries')
      .then((r) => {
        listBox.replaceChildren(
          h('h3', {}, 'Resumos salvos'),
          r.items.length
            ? r.items.map((it) => h('a', { class: 'recent-item', href: '#/summary/' + it.id }, icon('summary', 18), h('div', {}, h('strong', {}, it.title), h('small', { class: 'muted' }, fmtDate(it.createdAt)))))
            : h('p', { class: 'muted' }, 'Seus resumos aparecem aqui.')
        );
      })
      .catch(() => listBox.replaceChildren(h('h3', {}, 'Resumos salvos'), h('p', { class: 'muted' }, 'Não foi possível carregar.')));
  }
  loadList();

  return h(
    'div',
    { class: 'page' },
    pageHeader('Resumos inteligentes', 'Transforme textos em resumo, pontos importantes, mapa mental e perguntas de revisão.', 'summary'),
    aiBanner(ctx.state),
    h('div', { class: 'card' }, field('Título', title), field('Texto para resumir', text), h('div', { class: 'row space' }, counter, h('button', { class: 'btn ghost sm', type: 'button', onclick: () => fileInput.click() }, icon('upload'), 'Carregar .txt'), fileInput), btn),
    result,
    listBox
  );
}
