import { h, icon, toast, withBusy, banner, field } from '../ui.js';
import { api } from '../api.js';
import { state, go } from '../state.js';

function authShell(title, subtitle, ...content) {
  return h(
    'div',
    { class: 'auth-wrap' },
    h(
      'div',
      { class: 'auth-card card' },
      h('div', { class: 'brand center' }, h('span', { class: 'brand-mark' }, icon('sparkle', 22)), h('span', {}, 'StudyMind ', h('b', {}, 'AI'))),
      h('h1', {}, title),
      h('p', { class: 'muted' }, subtitle),
      content
    )
  );
}

function googleButton() {
  if (!state.config.googleLogin) return null;
  return h('div', {}, h('div', { class: 'divider' }, h('span', {}, 'ou')), h('a', { class: 'btn ghost block', href: '/api/auth/google' }, 'Entrar com Google'));
}

function errorFromQuery(query) {
  if (query.error === 'google') return banner('error', 'Não foi possível entrar com o Google. Tente de novo.');
  if (query.error === 'google_not_configured') return banner('warn', 'O login com Google não está configurado neste servidor.');
  return null;
}

export function loginView({ query }) {
  const email = h('input', { class: 'input', type: 'email', placeholder: 'voce@email.com', autocomplete: 'email', required: true });
  const pass = h('input', { class: 'input', type: 'password', placeholder: 'Sua senha', autocomplete: 'current-password', required: true });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Entrar');
  const form = h(
    'form',
    {
      class: 'form',
      onsubmit: (e) => {
        e.preventDefault();
        withBusy(btn, async () => {
          try {
            const r = await api('/auth/login', { method: 'POST', body: { email: email.value, password: pass.value } });
            state.user = r.user;
            go('#/');
          } catch (err) {
            toast(err.message, 'error');
          }
        });
      }
    },
    field('E-mail', email),
    field('Senha', pass),
    h('a', { class: 'link', href: '#/forgot' }, 'Esqueci minha senha'),
    btn
  );
  return authShell('Bem-vindo de volta', 'Entre para continuar estudando.', errorFromQuery(query), form, googleButton(), h('p', { class: 'muted center' }, 'Ainda não tem conta? ', h('a', { class: 'link', href: '#/register' }, 'Criar conta')));
}

export function registerView() {
  const name = h('input', { class: 'input', placeholder: 'Seu nome', autocomplete: 'name', required: true, minlength: '2' });
  const email = h('input', { class: 'input', type: 'email', placeholder: 'voce@email.com', autocomplete: 'email', required: true });
  const pass = h('input', { class: 'input', type: 'password', placeholder: 'Mínimo de 8 caracteres', autocomplete: 'new-password', required: true, minlength: '8' });
  const pass2 = h('input', { class: 'input', type: 'password', placeholder: 'Repita a senha', autocomplete: 'new-password', required: true });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Criar conta');
  const form = h(
    'form',
    {
      class: 'form',
      onsubmit: (e) => {
        e.preventDefault();
        if (pass.value !== pass2.value) return toast('As senhas não são iguais.', 'error');
        withBusy(btn, async () => {
          try {
            const r = await api('/auth/register', { method: 'POST', body: { name: name.value, email: email.value, password: pass.value } });
            state.user = r.user;
            toast('Conta criada! Bem-vindo(a) ao StudyMind AI.', 'ok');
            go('#/');
          } catch (err) {
            toast(err.message, 'error');
          }
        });
      }
    },
    field('Nome', name),
    field('E-mail', email),
    field('Senha', pass),
    field('Confirmar senha', pass2),
    btn
  );
  return authShell('Criar conta', 'Comece a estudar com inteligência artificial.', form, googleButton(), h('p', { class: 'muted center' }, 'Já tem conta? ', h('a', { class: 'link', href: '#/login' }, 'Entrar')));
}

export function forgotView() {
  const email = h('input', { class: 'input', type: 'email', placeholder: 'voce@email.com', autocomplete: 'email', required: true });
  const result = h('div');
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Enviar instruções');
  const form = h(
    'form',
    {
      class: 'form',
      onsubmit: (e) => {
        e.preventDefault();
        withBusy(btn, async () => {
          result.replaceChildren();
          try {
            const r = await api('/auth/forgot', { method: 'POST', body: { email: email.value } });
            result.replaceChildren(banner('info', r.message));
          } catch (err) {
            result.replaceChildren(banner('warn', err.message));
          }
        });
      }
    },
    field('E-mail da conta', email),
    btn
  );
  return authShell('Recuperar senha', 'Enviaremos um link para você criar uma nova senha.', form, result, h('p', { class: 'muted center' }, h('a', { class: 'link', href: '#/login' }, 'Voltar para o login')));
}

export function resetView({ query }) {
  const token = query.token || '';
  const pass = h('input', { class: 'input', type: 'password', placeholder: 'Mínimo de 8 caracteres', autocomplete: 'new-password', required: true, minlength: '8' });
  const pass2 = h('input', { class: 'input', type: 'password', placeholder: 'Repita a nova senha', autocomplete: 'new-password', required: true });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Salvar nova senha');
  const form = h(
    'form',
    {
      class: 'form',
      onsubmit: (e) => {
        e.preventDefault();
        if (pass.value !== pass2.value) return toast('As senhas não são iguais.', 'error');
        withBusy(btn, async () => {
          try {
            const r = await api('/auth/reset', { method: 'POST', body: { token, password: pass.value } });
            toast(r.message, 'ok');
            go('#/login');
          } catch (err) {
            toast(err.message, 'error');
          }
        });
      }
    },
    field('Nova senha', pass),
    field('Confirmar nova senha', pass2),
    btn
  );
  return authShell('Nova senha', 'Escolha uma senha nova para a sua conta.', token ? form : banner('error', 'Link inválido. Peça um novo na tela de recuperação.'), h('p', { class: 'muted center' }, h('a', { class: 'link', href: '#/login' }, 'Voltar para o login')));
}
