import { h, icon, aiBanner, fmtDate } from '../ui.js';
import { api } from '../api.js';

const SHORTCUTS = [
  { href: '#/solve', icon: 'camera', title: 'Resolver atividades', desc: 'Tire uma foto e receba a resolução passo a passo.' },
  { href: '#/exams', icon: 'exam', title: 'Criar provas', desc: 'Provas inéditas com correção automática e explicações.' },
  { href: '#/chat', icon: 'chat', title: 'Chat inteligente', desc: 'Tire dúvidas e estude qualquer matéria escolar.' },
  { href: '#/summary', icon: 'summary', title: 'Resumos inteligentes', desc: 'Resumo, pontos importantes e mapa mental de qualquer texto.' },
  { href: '#/tutor', icon: 'tutor', title: 'Professor particular', desc: 'Aulas adaptadas ao seu nível, com exercícios.' },
  { href: '#/history', icon: 'history', title: 'Histórico', desc: 'Volte às suas conversas, atividades, provas e resumos.' }
];

const TYPE_ICON = { chat: 'chat', tutor: 'tutor', solve: 'camera', exam: 'exam', summary: 'summary' };
const TYPE_HREF = { chat: '#/chat/', tutor: '#/tutor/', solve: '#/solve/', exam: '#/exams/', summary: '#/summary/' };

export async function homeView({ state }) {
  const u = state.user;
  const hr = new Date().getHours();
  const saudacao = hr < 5 ? 'Boa madrugada' : hr < 12 ? 'Bom dia' : hr < 18 ? 'Boa tarde' : 'Boa noite';
  const primeiro = u.name.trim().split(/\s+/)[0];

  const usageBox = h('div', { class: 'card' }, h('h3', {}, 'Seu uso de hoje'), h('p', { class: 'muted' }, 'Carregando…'));
  const recentBox = h('div', { class: 'card' }, h('h3', {}, 'Atividade recente'), h('p', { class: 'muted' }, 'Carregando…'));

  const page = h(
    'div',
    { class: 'page' },
    h('header', { class: 'hero' }, h('p', { class: 'eyebrow' }, 'StudyMind AI'), h('h1', {}, saudacao + ', ', h('span', { class: 'grad' }, primeiro), ' 👋'), h('p', { class: 'muted' }, 'O que vamos estudar hoje?')),
    aiBanner(state),
    h(
      'div',
      { class: 'grid tools' },
      SHORTCUTS.map((s) => h('a', { class: 'tool-card', href: s.href }, h('div', { class: 'tool-icon' }, icon(s.icon, 26)), h('h3', {}, s.title), h('p', { class: 'muted' }, s.desc)))
    ),
    u.favoriteSubjects.length
      ? h('div', { class: 'card' }, h('h3', {}, 'Suas matérias favoritas'), h('p', { class: 'muted' }, 'Toque para ter uma aula com o professor particular.'), h('div', { class: 'chips' }, u.favoriteSubjects.map((s) => h('a', { class: 'chip', href: '#/tutor?topic=' + encodeURIComponent(s) }, s))))
      : h('div', { class: 'card' }, h('h3', {}, 'Personalize seu perfil'), h('p', { class: 'muted' }, 'Escolha suas matérias favoritas para receber atalhos e respostas mais ajustadas a você.'), h('a', { class: 'btn ghost', href: '#/profile' }, 'Escolher matérias')),
    h('div', { class: 'grid two' }, usageBox, recentBox)
  );

  api('/usage')
    .then((r) => {
      usageBox.replaceChildren(
        h('h3', {}, 'Seu uso de hoje'),
        Object.values(r.tools).map((t) => {
          const pct = t.limit ? Math.min(100, Math.round((t.used / t.limit) * 100)) : 100;
          return h('div', { class: 'usage-row' }, h('div', { class: 'usage-top' }, h('span', {}, t.label), h('span', { class: 'muted' }, `${t.used} / ${t.limit}`)), h('div', { class: 'bar' }, h('i', { style: `width:${pct}%` })));
        }),
        r.plan === 'premium' ? null : h('a', { class: 'link', href: '#/plans' }, 'Ver planos com limites maiores')
      );
    })
    .catch(() => usageBox.replaceChildren(h('h3', {}, 'Seu uso de hoje'), h('p', { class: 'muted' }, 'Não foi possível carregar.')));

  api('/history?limit=5')
    .then((r) => {
      recentBox.replaceChildren(
        h('h3', {}, 'Atividade recente'),
        r.items.length
          ? r.items.map((it) => h('a', { class: 'recent-item', href: TYPE_HREF[it.type] + it.id }, icon(TYPE_ICON[it.type], 18), h('div', {}, h('strong', {}, it.title), h('small', { class: 'muted' }, it.subtitle + ' · ' + fmtDate(it.createdAt)))))
          : h('p', { class: 'muted' }, 'Nada por aqui ainda. Que tal começar por uma das ferramentas acima?')
      );
    })
    .catch(() => recentBox.replaceChildren(h('h3', {}, 'Atividade recente'), h('p', { class: 'muted' }, 'Não foi possível carregar.')));

  return page;
}
