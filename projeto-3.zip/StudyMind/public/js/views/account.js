import { h, icon, toast, withBusy, pageHeader, banner, field, select, SUBJECTS, SCHOOL_LEVELS } from '../ui.js';
import { api } from '../api.js';
import { state, go } from '../state.js';

export async function profileView() {
  const u = state.user;
  const name = h('input', { class: 'input', value: u.name, maxlength: '60', required: true });
  const level = select([['', 'Não informar'], ...SCHOOL_LEVELS.map((l) => [l, l])], u.schoolLevel || '');
  let selected = new Set(u.favoriteSubjects);
  const chips = h('div', { class: 'chips' });
  const custom = h('input', { class: 'input', placeholder: 'Outra matéria…', maxlength: '40' });

  function renderChips() {
    const all = [...new Set([...SUBJECTS, ...selected])];
    chips.replaceChildren(
      all.map((s) =>
        h('button', { type: 'button', class: 'chip selectable' + (selected.has(s) ? ' on' : ''), onclick: () => { if (selected.has(s)) selected.delete(s); else if (selected.size >= 12) toast('Escolha no máximo 12 matérias.', 'error'); else selected.add(s); renderChips(); } }, selected.has(s) ? icon('check', 14) : null, s)
      )
    );
  }
  renderChips();

  const saveBtn = h('button', { class: 'btn primary', type: 'button' }, 'Salvar perfil');
  saveBtn.addEventListener('click', () =>
    withBusy(saveBtn, async () => {
      try {
        const r = await api('/profile', { method: 'PUT', body: { name: name.value, schoolLevel: level.value, favoriteSubjects: [...selected] } });
        state.user = r.user;
        toast('Perfil salvo!', 'ok');
      } catch (e) {
        toast(e.message, 'error');
      }
    })
  );

  const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password' });
  const nw = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', minlength: '8' });
  const pwBtn = h('button', { class: 'btn ghost', type: 'button' }, u.hasPassword ? 'Trocar senha' : 'Criar senha');
  pwBtn.addEventListener('click', () =>
    withBusy(pwBtn, async () => {
      try {
        await api('/profile/password', { method: 'POST', body: { current: cur.value || undefined, next: nw.value } });
        cur.value = '';
        nw.value = '';
        state.user = { ...state.user, hasPassword: true };
        toast('Senha atualizada!', 'ok');
      } catch (e) {
        toast(e.message, 'error');
      }
    })
  );

  const delPass = h('input', { class: 'input', type: 'password', placeholder: u.hasPassword ? 'Digite sua senha para confirmar' : '', autocomplete: 'current-password' });
  const delBtn = h('button', { class: 'btn danger', type: 'button' }, 'Apagar minha conta');
  delBtn.addEventListener('click', () =>
    withBusy(delBtn, async () => {
      if (!confirm('Apagar a conta e TODO o histórico? Isso não pode ser desfeito.')) return;
      try {
        await api('/profile', { method: 'DELETE', body: { password: delPass.value || undefined } });
        state.user = null;
        toast('Conta apagada.', 'ok');
        go('#/login');
      } catch (e) {
        toast(e.message, 'error');
      }
    })
  );

  return h(
    'div',
    { class: 'page' },
    pageHeader('Meu perfil', 'Personalize sua experiência.', 'user'),
    h('div', { class: 'card' }, h('h3', {}, 'Dados pessoais'), h('div', { class: 'form-grid' }, field('Nome', name), field('E-mail', h('input', { class: 'input', value: u.email, disabled: true })), field('Nível escolar', level)), saveBtn),
    h('div', { class: 'card' }, h('h3', {}, 'Matérias favoritas'), h('p', { class: 'muted' }, 'Elas aparecem como atalhos na tela inicial e ajudam a IA a ajustar as respostas.'), chips, h('div', { class: 'row' }, custom, h('button', { class: 'btn ghost', type: 'button', onclick: () => { const v = custom.value.trim(); if (!v) return; if (selected.size >= 12) return toast('Escolha no máximo 12 matérias.', 'error'); selected.add(v); custom.value = ''; renderChips(); } }, icon('plus'), 'Adicionar')), h('p', { class: 'muted' }, 'Depois de escolher, toque em "Salvar perfil".')),
    h('div', { class: 'card' }, h('h3', {}, u.hasPassword ? 'Trocar senha' : 'Criar senha'), u.hasPassword ? null : h('p', { class: 'muted' }, 'Sua conta entra com o Google. Você pode criar uma senha para também entrar com e-mail.'), h('div', { class: 'form-grid' }, u.hasPassword ? field('Senha atual', cur) : null, field('Nova senha', nw, 'Mínimo de 8 caracteres')), pwBtn),
    h('div', { class: 'card danger-zone' }, h('h3', {}, 'Zona de perigo'), h('p', { class: 'muted' }, 'Apagar a conta remove seus dados e todo o histórico de forma permanente.'), u.hasPassword ? field('Confirmação', delPass) : null, delBtn)
  );
}

export async function plansView({ query }) {
  const data = await api('/plans');
  const u = state.user;
  let interval = data.billing.monthly || !data.billing.yearly ? 'monthly' : 'yearly';
  const free = data.plans.find((p) => p.id === 'free');
  const premium = data.plans.find((p) => p.id === 'premium');

  const priceBox = h('div', { class: 'price' });
  const action = h('div');
  const toggle = h('div', { class: 'tabs' });

  function priceText() {
    const p = premium.prices[interval];
    return p ? p + (interval === 'monthly' ? ' / mês' : ' / ano') : 'Preço a definir';
  }

  function render() {
    toggle.replaceChildren(['monthly', 'yearly'].map((i) => h('button', { type: 'button', class: 'tab' + (i === interval ? ' active' : ''), onclick: () => { interval = i; render(); } }, i === 'monthly' ? 'Mensal' : 'Anual')));
    priceBox.textContent = priceText();
    action.replaceChildren();
    if (u.plan === 'premium') {
      action.append(h('div', { class: 'badge premium' }, 'Seu plano atual'));
      if (data.billingConfigured) {
        const b = h('button', { class: 'btn ghost block', type: 'button' }, 'Gerenciar assinatura');
        b.addEventListener('click', () => withBusy(b, async () => { try { const r = await api('/billing/portal', { method: 'POST', body: {} }); location.href = r.url; } catch (e) { toast(e.message, 'error'); } }));
        action.append(b);
      }
    } else if (!data.billingConfigured) {
      action.append(h('button', { class: 'btn primary block', type: 'button', disabled: true }, 'Assinar indisponível'), h('small', { class: 'muted' }, 'Os pagamentos ainda não foram configurados pelo administrador deste site.'));
    } else if (!data.billing[interval]) {
      action.append(h('button', { class: 'btn primary block', type: 'button', disabled: true }, 'Indisponível'), h('small', { class: 'muted' }, 'Esta opção ainda não tem preço configurado.'));
    } else {
      const b = h('button', { class: 'btn primary block', type: 'button' }, icon('crown'), 'Assinar Premium');
      b.addEventListener('click', () => withBusy(b, async () => { try { const r = await api('/billing/checkout', { method: 'POST', body: { interval } }); location.href = r.url; } catch (e) { toast(e.message, 'error'); } }));
      action.append(b);
    }
  }
  render();

  const limitRows = data.tools.map((t) => h('tr', {}, h('td', {}, t.label), h('td', {}, String(free.limits[t.id]) + ' / dia'), h('td', {}, String(premium.limits[t.id]) + ' / dia')));

  return h(
    'div',
    { class: 'page' },
    pageHeader('Planos', 'Escolha o plano ideal para os seus estudos.', 'crown'),
    query.status === 'success' ? banner('info', 'Pagamento enviado! Assim que o provedor confirmar, seu plano Premium é ativado automaticamente. Se não mudar em alguns minutos, recarregue a página.') : null,
    query.status === 'cancel' ? banner('warn', 'O pagamento foi cancelado. Nada foi cobrado.') : null,
    !data.billingConfigured ? banner('warn', h('strong', {}, 'Pagamentos não configurados. '), 'O administrador precisa definir o provedor de pagamento (Stripe) no servidor. Enquanto isso, não é possível assinar e nenhuma cobrança é feita.') : null,
    h(
      'div',
      { class: 'grid two plans' },
      h('div', { class: 'card plan' + (u.plan === 'free' ? ' current' : '') }, h('h2', {}, free.name), h('div', { class: 'price' }, free.price), h('ul', { class: 'check-list' }, free.features.map((f) => h('li', {}, icon('check', 16), h('span', {}, f)))), u.plan === 'free' ? h('div', { class: 'badge free' }, 'Seu plano atual') : null),
      h('div', { class: 'card plan featured' + (u.plan === 'premium' ? ' current' : '') }, h('div', { class: 'ribbon' }, 'Premium'), h('h2', {}, premium.name), toggle, priceBox, h('ul', { class: 'check-list' }, premium.features.map((f) => h('li', {}, icon('check', 16), h('span', {}, f)))), action)
    ),
    h('div', { class: 'card' }, h('h3', {}, 'Limites de uso por plano'), h('div', { class: 'table-wrap' }, h('table', { class: 'table' }, h('thead', {}, h('tr', {}, h('th', {}, 'Ferramenta'), h('th', {}, 'Gratuito'), h('th', {}, 'Premium'))), h('tbody', {}, limitRows))), h('small', { class: 'muted' }, 'Os limites zeram todos os dias à meia-noite (horário de Brasília).'))
  );
}
