import { h, icon, toast, withBusy, aiBanner, pageHeader, mdBox, field, select, spinner, fmtDate, SUBJECTS, SCHOOL_LEVELS } from '../ui.js';
import { api } from '../api.js';

const DIFF = { facil: 'Fácil', medio: 'Média', dificil: 'Difícil' };
const LETTERS = ['A', 'B', 'C', 'D', 'E'];

export async function examsView(ctx) {
  const area = h('div');
  const listBox = h('div', { class: 'card' }, h('h3', {}, 'Suas provas'), h('p', { class: 'muted' }, 'Carregando…'));
  const root = h('div', { class: 'page' }, pageHeader('Criar provas', 'Provas inéditas geradas por IA, com correção automática, pontuação e explicações.', 'exam'), aiBanner(ctx.state), area, listBox);

  // ---------- formulário ----------
  function showForm() {
    const subject = h('input', { class: 'input', list: 'exam-subjects', placeholder: 'Ex.: Matemática', maxlength: '60' });
    const topic = h('input', { class: 'input', placeholder: 'Ex.: Equações do 2º grau', maxlength: '120' });
    const diff = select([['facil', 'Fácil'], ['medio', 'Média'], ['dificil', 'Difícil']], 'medio');
    const level = select(SCHOOL_LEVELS.map((l) => [l, l]), ctx.state.user.schoolLevel || 'Ensino médio');
    const choices = select([['4', '4 alternativas (A–D)'], ['5', '5 alternativas (A–E)']], '4');
    const count = h('input', { class: 'range', type: 'range', min: '1', max: '20', value: '10' });
    const countOut = h('b', {}, '10');
    count.addEventListener('input', () => (countOut.textContent = count.value));
    const btn = h('button', { class: 'btn primary block', type: 'button' }, icon('sparkle'), 'Gerar prova');

    btn.addEventListener('click', () => {
      if (subject.value.trim().length < 2) return toast('Informe a matéria.', 'error');
      if (topic.value.trim().length < 2) return toast('Informe o assunto.', 'error');
      withBusy(btn, async () => {
        area.replaceChildren(h('div', { class: 'card' }, spinner('A IA está criando suas questões. Isso pode levar até um minuto…')));
        try {
          const r = await api('/exams', { method: 'POST', body: { subject: subject.value.trim(), topic: topic.value.trim(), difficulty: diff.value, count: Number(count.value), choices: Number(choices.value), level: level.value } });
          takeExam(r.exam, []);
          loadList();
        } catch (e) {
          toast(e.message, 'error');
          showForm();
          area.prepend(h('div', { class: 'banner error' }, icon('alert'), h('div', {}, e.message)));
        }
      });
    });

    area.replaceChildren(
      h(
        'div',
        { class: 'card' },
        h('datalist', { id: 'exam-subjects' }, SUBJECTS.map((s) => h('option', { value: s }))),
        h('div', { class: 'form-grid' }, field('Matéria', subject), field('Assunto', topic), field('Dificuldade', diff), field('Nível escolar', level), field('Alternativas', choices), field('Quantidade de questões', h('div', { class: 'range-wrap' }, count, countOut))),
        btn
      )
    );
  }

  // ---------- fazer a prova ----------
  function takeExam(exam, attempts) {
    const answers = exam.questions.map(() => null);
    const progress = h('small', { class: 'muted' }, `0 de ${exam.questions.length} respondidas`);
    const submit = h('button', { class: 'btn primary block', type: 'button' }, icon('check'), 'Enviar respostas e corrigir');

    const qs = exam.questions.map((q, qi) =>
      h(
        'div',
        { class: 'card q-card' },
        h('div', { class: 'q-num' }, 'Questão ' + q.n),
        h('p', { class: 'q-text' }, q.enunciado),
        h(
          'div',
          { class: 'opts' },
          q.alternativas.map((alt, ai) =>
            h(
              'label',
              { class: 'opt' },
              h('input', {
                type: 'radio',
                name: 'q' + qi,
                onchange: () => {
                  answers[qi] = ai;
                  progress.textContent = `${answers.filter((a) => a !== null).length} de ${answers.length} respondidas`;
                }
              }),
              h('span', { class: 'opt-letter' }, LETTERS[ai]),
              h('span', {}, alt)
            )
          )
        )
      )
    );

    submit.addEventListener('click', () => {
      const faltam = answers.filter((a) => a === null).length;
      if (faltam && !confirm(`Você deixou ${faltam} questão(ões) em branco. Enviar mesmo assim?`)) return;
      withBusy(submit, async () => {
        try {
          const r = await api(`/exams/${exam.id}/submit`, { method: 'POST', body: { answers } });
          showResult(exam, r);
          loadList();
        } catch (e) {
          toast(e.message, 'error');
        }
      });
    });

    area.replaceChildren(
      h('div', { class: 'card' }, h('h2', {}, exam.title), h('p', { class: 'muted' }, `${exam.subject} · ${exam.topic} · ${DIFF[exam.difficulty]} · ${exam.questions.length} questões`), progress),
      qs,
      submit,
      attempts.length ? h('div', { class: 'card' }, h('h3', {}, 'Tentativas anteriores'), attempts.map((a) => h('div', { class: 'attempt' }, h('span', {}, fmtDate(a.createdAt)), h('b', {}, `${a.score}/${a.total} (${Math.round((a.score / a.total) * 100)}%)`)))) : null
    );
    window.scrollTo(0, 0);
  }

  // ---------- resultado ----------
  function showResult(exam, r) {
    const color = r.percent >= 70 ? 'var(--ok)' : r.percent >= 50 ? 'var(--warn)' : 'var(--danger)';
    const msg = r.percent >= 90 ? 'Excelente! 🎉' : r.percent >= 70 ? 'Muito bem! 👏' : r.percent >= 50 ? 'Bom começo. Revise as explicações abaixo.' : 'Vamos revisar? As explicações abaixo vão ajudar.';
    area.replaceChildren(
      h('div', { class: 'card center result-head' }, h('div', { class: 'ring', style: `--p:${r.percent};--c:${color}` }, h('div', { class: 'ring-in' }, h('b', {}, r.percent + '%'), h('small', {}, `${r.score}/${r.total}`))), h('h2', {}, `Nota ${String(r.nota).replace('.', ',')}`), h('p', { class: 'muted' }, msg)),
      r.results.map((q) =>
        h(
          'div',
          { class: 'card q-card ' + (q.acertou ? 'right' : 'wrong') },
          h('div', { class: 'q-num' }, `Questão ${q.n} · `, q.acertou ? h('span', { class: 'ok-text' }, 'Correta') : q.escolhida === null ? h('span', { class: 'bad-text' }, 'Em branco') : h('span', { class: 'bad-text' }, 'Incorreta')),
          h('p', { class: 'q-text' }, q.enunciado),
          h('div', { class: 'opts' }, q.alternativas.map((alt, ai) => h('div', { class: 'opt static' + (ai === q.correta ? ' is-correct' : '') + (ai === q.escolhida && !q.acertou ? ' is-wrong' : '') }, h('span', { class: 'opt-letter' }, LETTERS[ai]), h('span', {}, alt), ai === q.correta ? icon('check', 18) : ai === q.escolhida ? icon('x', 18) : null))),
          h('div', { class: 'explain' }, h('strong', {}, 'Explicação'), mdBox(q.explicacao))
        )
      ),
      h('div', { class: 'row wrap' }, h('button', { class: 'btn ghost', onclick: () => load(exam.id) }, icon('history'), 'Refazer esta prova'), h('button', { class: 'btn primary', onclick: () => { history.replaceState(null, '', '#/exams'); showForm(); } }, icon('plus'), 'Nova prova'))
    );
    window.scrollTo(0, 0);
  }

  async function load(id) {
    area.replaceChildren(h('div', { class: 'card' }, spinner('Abrindo a prova…')));
    try {
      const r = await api('/exams/' + id);
      takeExam(r.exam, r.attempts);
    } catch (e) {
      area.replaceChildren(h('div', { class: 'banner error' }, icon('alert'), h('div', {}, e.message)));
    }
  }

  // ---------- lista ----------
  function loadList() {
    api('/exams')
      .then((r) => {
        listBox.replaceChildren(
          h('h3', {}, 'Suas provas'),
          r.items.length
            ? r.items.map((e) =>
                h(
                  'div',
                  { class: 'history-item' },
                  h('div', { class: 'history-main' }, h('div', { class: 'tool-icon sm' }, icon('exam', 20)), h('div', {}, h('strong', {}, e.title), h('small', { class: 'muted' }, `${e.subject} · ${DIFF[e.difficulty]} · ${e.total} questões · ` + (e.attempts ? `melhor nota ${e.bestPercent}%` : 'ainda não feita')))),
                  h('div', { class: 'row' }, h('button', { class: 'btn ghost sm', type: 'button', onclick: () => load(e.id) }, e.attempts ? 'Refazer' : 'Fazer'), h('button', { class: 'icon-btn danger', type: 'button', 'aria-label': 'Apagar prova', onclick: async () => { if (!confirm('Apagar esta prova e as tentativas dela?')) return; try { await api('/exams/' + e.id, { method: 'DELETE' }); loadList(); } catch (err) { toast(err.message, 'error'); } } }, icon('trash')))
                )
              )
            : h('p', { class: 'muted' }, 'As provas que você gerar aparecem aqui para refazer quando quiser.')
        );
      })
      .catch(() => listBox.replaceChildren(h('h3', {}, 'Suas provas'), h('p', { class: 'muted' }, 'Não foi possível carregar.')));
  }

  loadList();
  if (ctx.params.id) load(ctx.params.id);
  else showForm();
  return root;
}
