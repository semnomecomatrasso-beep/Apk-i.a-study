import { h, icon, toast, aiBanner, pageHeader, mdBox, field, select, fmtDate, SUBJECTS } from '../ui.js';
import { api } from '../api.js';
import { go } from '../state.js';

const LEVELS = [['iniciante', 'Iniciante'], ['intermediario', 'Intermediário'], ['avancado', 'Avançado']];
const STYLES = [
  ['simples', 'Explicação simples'],
  ['analogias', 'Com analogias'],
  ['passo_a_passo', 'Passo a passo'],
  ['dia_a_dia', 'Exemplos do dia a dia'],
  ['exercicios', 'Mais exercícios']
];

export const chatView = (ctx) => conversationPage(ctx, 'chat');
export const tutorView = (ctx) => conversationPage(ctx, 'tutor');

function conversationPage(ctx, kind) {
  const tutor = kind === 'tutor';
  let convId = ctx.params.id ? Number(ctx.params.id) : null;
  let busy = false;

  const listEl = h('div', { class: 'conv-items' });
  const msgsEl = h('div', { class: 'messages' });
  const input = h('textarea', { class: 'input chat-input', rows: '1', maxlength: '4000', placeholder: tutor ? 'Responda ao professor ou peça outra explicação…' : 'Pergunte qualquer coisa sobre seus estudos…' });
  const sendBtn = h('button', { class: 'btn primary icon-btn', type: 'button', 'aria-label': 'Enviar' }, icon('send'));

  const levelSel = select(LEVELS, 'intermediario');
  const styleSel = select(STYLES, 'simples');
  const topicTitle = h('strong', {});

  const chatArea = h('div', { class: 'chat-area' });
  const setupArea = h('div', { class: 'card setup' });

  function addMessage(role, content) {
    const bubble =
      role === 'assistant'
        ? h('div', { class: 'msg assistant' }, h('div', { class: 'msg-avatar' }, icon('sparkle', 16)), mdBox(content, 'bubble'))
        : role === 'error'
          ? h('div', { class: 'msg error' }, icon('alert', 18), h('div', { class: 'bubble' }, content))
          : h('div', { class: 'msg user' }, h('div', { class: 'bubble' }, content));
    msgsEl.append(bubble);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    return bubble;
  }

  function showTyping() {
    const el = h('div', { class: 'msg assistant' }, h('div', { class: 'msg-avatar' }, icon('sparkle', 16)), h('div', { class: 'bubble typing' }, h('i'), h('i'), h('i')));
    msgsEl.append(el);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    return el;
  }

  function emptyState() {
    msgsEl.replaceChildren(
      h(
        'div',
        { class: 'empty-chat' },
        icon(tutor ? 'tutor' : 'chat', 36),
        h('h3', {}, tutor ? 'Sua aula começa aqui' : 'Como posso ajudar nos seus estudos?'),
        tutor ? null : h('div', { class: 'chips' }, ['Explique frações com exemplos', 'Me ajude a entender a Revolução Francesa', 'Como resolver equações do 2º grau?'].map((t) => h('button', { class: 'chip', type: 'button', onclick: () => send(t) }, t)))
      )
    );
  }

  function setBusy(v) {
    busy = v;
    sendBtn.disabled = v;
    input.disabled = v;
    if (!v) input.focus();
  }

  async function send(text, topic) {
    text = (text || '').trim();
    if (!text || busy) return;
    if (msgsEl.querySelector('.empty-chat')) msgsEl.replaceChildren();
    setBusy(true);
    addMessage('user', text);
    input.value = '';
    autosize();
    const typing = showTyping();
    try {
      const body = tutor ? { conversationId: convId || undefined, message: text, level: levelSel.value, style: styleSel.value, topic } : { conversationId: convId || undefined, message: text };
      const r = await api(tutor ? '/tutor' : '/chat', { method: 'POST', body });
      typing.remove();
      addMessage('assistant', r.reply);
      if (!convId) {
        convId = r.conversationId;
        history.replaceState(null, '', `#/${kind}/${convId}`);
      }
      if (tutor && r.meta) topicTitle.textContent = r.meta.topic;
      loadList();
    } catch (e) {
      typing.remove();
      addMessage('error', e.message);
    } finally {
      setBusy(false);
    }
  }

  function autosize() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  }
  input.addEventListener('input', autosize);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send(input.value);
    }
  });
  sendBtn.addEventListener('click', () => send(input.value));

  async function loadList() {
    try {
      const r = await api('/conversations?kind=' + kind);
      listEl.replaceChildren(
        r.items.length
          ? r.items.map((c) =>
              h(
                'div',
                { class: 'conv-item' + (c.id === convId ? ' active' : '') },
                h('a', { href: `#/${kind}/${c.id}` }, h('strong', {}, c.title), h('small', { class: 'muted' }, fmtDate(c.updatedAt))),
                h('button', {
                  class: 'icon-btn danger sm',
                  type: 'button',
                  'aria-label': 'Apagar conversa',
                  onclick: async () => {
                    if (!confirm('Apagar esta conversa? Não dá para desfazer.')) return;
                    try {
                      await api('/conversations/' + c.id, { method: 'DELETE' });
                      if (c.id === convId) go(`#/${kind}`);
                      else loadList();
                    } catch (e) {
                      toast(e.message, 'error');
                    }
                  }
                }, icon('trash', 16))
              )
            )
          : h('p', { class: 'muted pad' }, 'Nenhuma conversa ainda.')
      );
    } catch {
      listEl.replaceChildren(h('p', { class: 'muted pad' }, 'Não foi possível carregar.'));
    }
  }

  async function openConversation() {
    msgsEl.replaceChildren(h('div', { class: 'loading-box' }, h('div', { class: 'spinner' })));
    try {
      const c = await api('/conversations/' + convId);
      msgsEl.replaceChildren();
      c.messages.forEach((m) => addMessage(m.role, m.content));
      if (tutor && c.meta) {
        topicTitle.textContent = c.meta.topic || '';
        if (c.meta.level) levelSel.value = c.meta.level;
        if (c.meta.style) styleSel.value = c.meta.style;
      }
    } catch (e) {
      msgsEl.replaceChildren(h('div', { class: 'banner error' }, icon('alert'), h('div', {}, e.message)));
    }
  }

  // ----- montagem -----
  const quick = tutor
    ? h(
        'div',
        { class: 'quick' },
        h('button', { class: 'chip', type: 'button', onclick: () => { levelSel.value = levelSel.value === 'avancado' ? 'intermediario' : 'iniciante'; send('Pode explicar de um jeito mais fácil?'); } }, 'Mais fácil'),
        h('button', { class: 'chip', type: 'button', onclick: () => { levelSel.value = levelSel.value === 'iniciante' ? 'intermediario' : 'avancado'; send('Pode aprofundar e deixar mais difícil?'); } }, 'Mais difícil'),
        h('button', { class: 'chip', type: 'button', onclick: () => send('Me dê um exemplo prático.') }, 'Dê um exemplo'),
        h('button', { class: 'chip', type: 'button', onclick: () => send('Me passe mais exercícios para praticar.') }, 'Mais exercícios')
      )
    : null;

  chatArea.append(
    tutor ? h('div', { class: 'tutor-bar' }, h('div', {}, h('small', { class: 'muted' }, 'Assunto'), topicTitle), h('div', { class: 'tutor-sel' }, field('Nível', levelSel), field('Estilo', styleSel))) : null,
    msgsEl,
    quick,
    h('div', { class: 'composer' }, input, sendBtn)
  );

  if (tutor) {
    const topic = h('input', { class: 'input', list: 'subjects-list', placeholder: 'Ex.: Frações, Fotossíntese, Segunda Guerra…', maxlength: '120', value: ctx.query.topic || '' });
    const lvl = select(LEVELS, 'intermediario');
    const sty = select(STYLES, 'simples');
    const startBtn = h('button', { class: 'btn primary block', type: 'button' }, icon('tutor'), 'Começar aula');
    startBtn.addEventListener('click', () => {
      if (topic.value.trim().length < 2) return toast('Informe o assunto da aula.', 'error');
      levelSel.value = lvl.value;
      styleSel.value = sty.value;
      topicTitle.textContent = topic.value.trim();
      setupArea.hidden = true;
      chatArea.hidden = false;
      msgsEl.replaceChildren();
      send(`Quero aprender sobre: ${topic.value.trim()}.`, topic.value.trim());
    });
    setupArea.append(
      h('h3', {}, 'Nova aula'),
      h('p', { class: 'muted' }, 'Diga o assunto, seu nível e como prefere que o professor explique. Você pode mudar isso durante a aula.'),
      h('datalist', { id: 'subjects-list' }, SUBJECTS.map((s) => h('option', { value: s }))),
      field('Assunto', topic),
      h('div', { class: 'form-grid' }, field('Seu nível', lvl), field('Estilo de explicação', sty)),
      startBtn
    );
    setupArea.hidden = Boolean(convId);
    chatArea.hidden = !convId;
  } else {
    setupArea.hidden = true;
  }

  const sidebar = h('aside', { class: 'conv-side card' }, h('a', { class: 'btn primary block', href: `#/${kind}` }, icon('plus'), tutor ? 'Nova aula' : 'Nova conversa'), listEl);
  const page = h(
    'div',
    { class: 'page wide' },
    pageHeader(tutor ? 'Professor particular' : 'Chat inteligente', tutor ? 'Aulas adaptadas ao seu nível, com exemplos e exercícios.' : 'Tire dúvidas e estude qualquer matéria escolar.', tutor ? 'tutor' : 'chat'),
    aiBanner(ctx.state),
    h('div', { class: 'conv-layout' }, sidebar, h('section', { class: 'conv-main card' }, setupArea, chatArea))
  );

  loadList();
  if (convId) openConversation();
  else {
    if (!tutor) {
      emptyState();
      if (ctx.query.q) input.value = ctx.query.q;
    }
  }
  return page;
}
