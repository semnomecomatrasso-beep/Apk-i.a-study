import { h, icon, toast, pageHeader, fmtDate } from '../ui.js';
import { api } from '../api.js';

const TYPES = [
  ['all', 'Tudo'],
  ['chat', 'Chat'],
  ['tutor', 'Professor'],
  ['solve', 'Atividades'],
  ['exam', 'Provas'],
  ['summary', 'Resumos']
];
const ICON = { chat: 'chat', tutor: 'tutor', solve: 'camera', exam: 'exam', summary: 'summary' };
const HREF = { chat: '#/chat/', tutor: '#/tutor/', solve: '#/solve/', exam: '#/exams/', summary: '#/summary/' };
const DEL = { chat: '/conversations/', tutor: '/conversations/', solve: '/solve/', exam: '/exams/', summary: '/summaries/' };

export async function historyView() {
  const data = await api('/history?limit=100');
  let items = data.items;
  let filter = 'all';
  const tabs = h('div', { class: 'tabs' });
  const list = h('div', { class: 'history-list' });

  function renderTabs() {
    tabs.replaceChildren(TYPES.map(([id, label]) => h('button', { type: 'button', class: 'tab' + (id === filter ? ' active' : ''), onclick: () => { filter = id; renderTabs(); renderList(); } }, label)));
  }

  function renderList() {
    const shown = items.filter((i) => filter === 'all' || i.type === filter);
    if (!shown.length) {
      list.replaceChildren(h('div', { class: 'empty card' }, icon('history', 32), h('p', { class: 'muted' }, 'Nada por aqui ainda.')));
      return;
    }
    list.replaceChildren(
      shown.map((it) =>
        h(
          'div',
          { class: 'history-item card' },
          h('a', { class: 'history-main', href: HREF[it.type] + it.id }, h('div', { class: 'tool-icon sm' }, icon(ICON[it.type], 20)), h('div', {}, h('strong', {}, it.title), h('small', { class: 'muted' }, it.subtitle + ' · ' + fmtDate(it.createdAt)))),
          h('button', {
            class: 'icon-btn danger',
            type: 'button',
            title: 'Apagar',
            'aria-label': 'Apagar',
            onclick: async () => {
              if (!confirm('Apagar este item do histórico? Não dá para desfazer.')) return;
              try {
                await api(DEL[it.type] + it.id, { method: 'DELETE' });
                items = items.filter((x) => !(x.type === it.type && x.id === it.id));
                renderList();
                toast('Item apagado.', 'ok');
              } catch (e) {
                toast(e.message, 'error');
              }
            }
          }, icon('trash'))
        )
      )
    );
  }

  renderTabs();
  renderList();
  return h('div', { class: 'page' }, pageHeader('Histórico', 'Tudo o que você já fez no StudyMind AI.', 'history'), tabs, list);
}
