import { h, icon, toast, withBusy, aiBanner, pageHeader, mdBox, copyText, field, select, spinner, fmtDate, SUBJECTS } from '../ui.js';
import { api } from '../api.js';
import { go } from '../state.js';

const MAX_SIDE = 1600;

// Reduz a foto no próprio aparelho antes de enviar (mais rápido e dentro do limite)
function prepareImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      URL.revokeObjectURL(url);
      resolve({ mediaType: 'image/jpeg', data: dataUrl.split(',')[1], preview: dataUrl });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Não foi possível ler esta imagem. Use uma foto JPG ou PNG.'));
    };
    img.src = url;
  });
}

async function detail(id) {
  const r = await api('/solve/' + id);
  return h(
    'div',
    { class: 'page' },
    pageHeader('Atividade resolvida', r.subject ? r.subject + ' · ' + fmtDate(r.createdAt) : fmtDate(r.createdAt), 'camera'),
    r.note ? h('div', { class: 'card' }, h('strong', {}, 'Sua observação: '), r.note) : null,
    h('div', { class: 'card' }, mdBox(r.answer)),
    h('div', { class: 'row' }, h('button', { class: 'btn ghost', onclick: () => copyText(r.answer) }, icon('copy'), 'Copiar'), h('a', { class: 'btn primary', href: '#/solve' }, 'Resolver outra'))
  );
}

export async function solveView(ctx) {
  if (ctx.params.id) return detail(ctx.params.id);

  let image = null;
  const preview = h('div', { class: 'preview', hidden: true });
  const result = h('div');
  const subject = select([['', 'Matéria (opcional)'], ...SUBJECTS.map((s) => [s, s])], '');
  const note = h('textarea', { class: 'input', rows: '2', maxlength: '1000', placeholder: 'Ex.: resolva só a questão 2 / explique bem devagar' });

  async function onFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    try {
      image = await prepareImage(file);
      preview.hidden = false;
      preview.replaceChildren(h('img', { src: image.preview, alt: 'Foto da atividade' }), h('button', { class: 'icon-btn danger', type: 'button', 'aria-label': 'Remover imagem', onclick: () => { image = null; preview.hidden = true; preview.replaceChildren(); } }, icon('x')));
      result.replaceChildren();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  const cam = h('input', { type: 'file', accept: 'image/*', capture: 'environment', hidden: true, onchange: onFile });
  const pick = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: onFile });
  const solveBtn = h('button', { class: 'btn primary block', type: 'button' }, icon('sparkle'), 'Resolver com IA');

  solveBtn.addEventListener('click', () => {
    if (!image) return toast('Tire uma foto ou envie uma imagem primeiro.', 'error');
    withBusy(solveBtn, async () => {
      result.replaceChildren(spinner('A IA está analisando a imagem e montando a resolução…'));
      try {
        const r = await api('/solve', { method: 'POST', body: { image: { mediaType: image.mediaType, data: image.data }, subject: subject.value || undefined, note: note.value.trim() || undefined } });
        result.replaceChildren(
          h('div', { class: 'card result' }, h('h3', {}, 'Resolução'), mdBox(r.answer)),
          h('div', { class: 'row' }, h('button', { class: 'btn ghost', onclick: () => copyText(r.answer) }, icon('copy'), 'Copiar'), h('button', { class: 'btn ghost', onclick: () => go('#/solve') }, icon('plus'), 'Nova atividade'))
        );
        loadList();
      } catch (err) {
        result.replaceChildren(h('div', { class: 'banner error' }, icon('alert'), h('div', {}, err.message)));
      }
    });
  });

  const listBox = h('div', { class: 'card' }, h('h3', {}, 'Atividades recentes'), h('p', { class: 'muted' }, 'Carregando…'));
  function loadList() {
    api('/solve')
      .then((r) => {
        listBox.replaceChildren(
          h('h3', {}, 'Atividades recentes'),
          r.items.length
            ? r.items.map((it) => h('a', { class: 'recent-item', href: '#/solve/' + it.id }, icon('camera', 18), h('div', {}, h('strong', {}, it.preview || 'Atividade'), h('small', { class: 'muted' }, (it.subject ? it.subject + ' · ' : '') + fmtDate(it.createdAt)))))
            : h('p', { class: 'muted' }, 'Suas atividades resolvidas aparecem aqui.')
        );
      })
      .catch(() => listBox.replaceChildren(h('h3', {}, 'Atividades recentes'), h('p', { class: 'muted' }, 'Não foi possível carregar.')));
  }
  loadList();

  return h(
    'div',
    { class: 'page' },
    pageHeader('Resolver atividades', 'Tire uma foto ou envie uma imagem e receba a resolução com explicação passo a passo.', 'camera'),
    aiBanner(ctx.state),
    h(
      'div',
      { class: 'card' },
      h('div', { class: 'row wrap' }, h('button', { class: 'btn primary', type: 'button', onclick: () => cam.click() }, icon('camera'), 'Tirar foto'), h('button', { class: 'btn ghost', type: 'button', onclick: () => pick.click() }, icon('upload'), 'Enviar imagem'), cam, pick),
      preview,
      h('div', { class: 'form-grid' }, field('Matéria', subject), field('Observação', note)),
      solveBtn,
      h('small', { class: 'muted' }, 'A foto é enviada para análise e não fica guardada: só o texto da resolução vai para o seu histórico.')
    ),
    result,
    listBox
  );
}
