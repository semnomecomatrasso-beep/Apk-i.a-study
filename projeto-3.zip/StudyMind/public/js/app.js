import { state, go } from './state.js';
import { api, setUnauthorizedHandler } from './api.js';
import { h, icon, toast, spinner } from './ui.js';
import { loginView, registerView, forgotView, resetView } from './views/auth.js';
import { homeView } from './views/home.js';
import { solveView } from './views/solve.js';
import { examsView } from './views/exams.js';
import { chatView, tutorView } from './views/chat.js';
import { summaryView } from './views/summary.js';
import { historyView } from './views/history.js';
import { profileView, plansView } from './views/account.js';

const NAV = [
  { id: 'home', path: '/', icon: 'home', label: 'Início' },
  { id: 'solve', path: '/solve', icon: 'camera', label: 'Resolver atividades' },
  { id: 'exams', path: '/exams', icon: 'exam', label: 'Criar provas' },
  { id: 'chat', path: '/chat', icon: 'chat', label: 'Chat inteligente' },
  { id: 'summary', path: '/summary', icon: 'summary', label: 'Resumos' },
  { id: 'tutor', path: '/tutor', icon: 'tutor', label: 'Professor particular' },
  { id: 'history', path: '/history', icon: 'history', label: 'Histórico' },
  { id: 'plans', path: '/plans', icon: 'crown', label: 'Planos' },
  { id: 'profile', path: '/profile', icon: 'user', label: 'Meu perfil' }
];
const BOTTOM = ['home', 'solve', 'exams', 'chat'];

const ROUTES = [
  { re: /^\/$/, view: homeView, nav: 'home' },
  { re: /^\/solve(?:\/(\d+))?$/, view: solveView, nav: 'solve' },
  { re: /^\/exams(?:\/(\d+))?$/, view: examsView, nav: 'exams' },
  { re: /^\/chat(?:\/(\d+))?$/, view: chatView, nav: 'chat' },
  { re: /^\/summary(?:\/(\d+))?$/, view: summaryView, nav: 'summary' },
  { re: /^\/tutor(?:\/(\d+))?$/, view: tutorView, nav: 'tutor' },
  { re: /^\/history$/, view: historyView, nav: 'history' },
  { re: /^\/profile$/, view: profileView, nav: 'profile' },
  { re: /^\/plans$/, view: plansView, nav: 'plans' },
  { re: /^\/login$/, view: loginView, guest: true },
  { re: /^\/register$/, view: registerView, guest: true },
  { re: /^\/forgot$/, view: forgotView, guest: true },
  { re: /^\/reset$/, view: resetView, guest: true }
];

const app = document.getElementById('app');

function parseHash() {
  const raw = location.hash.slice(1) || '/';
  const [path, q = ''] = raw.split('?');
  return { path, query: Object.fromEntries(new URLSearchParams(q)) };
}

function initial(name) {
  return (name || '?').trim().charAt(0).toUpperCase();
}

async function logout() {
  try {
    await api('/auth/logout', { method: 'POST' });
  } catch {
    // mesmo com erro de rede, sai da tela
  }
  state.user = null;
  go('#/login');
}

function shell(content, activeNav) {
  const side = h('aside', { class: 'sidebar' });
  const overlay = h('div', { class: 'overlay', onclick: () => document.body.classList.remove('drawer-open') });
  const toggle = () => document.body.classList.toggle('drawer-open');

  side.append(
    h('div', { class: 'brand' }, h('span', { class: 'brand-mark' }, icon('sparkle', 20)), h('span', {}, 'StudyMind ', h('b', {}, 'AI'))),
    h(
      'nav',
      { class: 'nav' },
      NAV.map((n) =>
        h('a', { href: '#' + n.path, class: 'nav-link' + (n.id === activeNav ? ' active' : ''), onclick: () => document.body.classList.remove('drawer-open') }, icon(n.icon), h('span', {}, n.label))
      )
    ),
    h(
      'div',
      { class: 'userbox' },
      h('div', { class: 'avatar' }, initial(state.user.name)),
      h('div', { class: 'userinfo' }, h('strong', {}, state.user.name), h('span', { class: 'badge ' + state.user.plan }, state.user.plan === 'premium' ? 'Premium' : 'Gratuito')),
      h('button', { class: 'icon-btn ghost', title: 'Sair', 'aria-label': 'Sair', onclick: logout }, icon('logout'))
    )
  );

  const topbar = h(
    'div',
    { class: 'topbar' },
    h('button', { class: 'icon-btn ghost', 'aria-label': 'Abrir menu', onclick: toggle }, icon('menu', 24)),
    h('div', { class: 'brand small' }, h('span', { class: 'brand-mark' }, icon('sparkle', 16)), h('span', {}, 'StudyMind ', h('b', {}, 'AI')))
  );

  const bottom = h(
    'nav',
    { class: 'bottom-nav' },
    BOTTOM.map((id) => {
      const n = NAV.find((x) => x.id === id);
      return h('a', { href: '#' + n.path, class: id === activeNav ? 'active' : '' }, icon(n.icon, 22), h('span', {}, n.label.split(' ')[0]));
    }),
    h('button', { type: 'button', onclick: toggle }, icon('more', 22), h('span', {}, 'Mais'))
  );

  return h('div', { class: 'layout' }, side, overlay, topbar, h('main', { class: 'main' }, content), bottom);
}

let routeToken = 0;

async function route() {
  const token = ++routeToken;
  document.body.classList.remove('drawer-open');
  const { path, query } = parseHash();
  const r = ROUTES.find((x) => x.re.test(path));
  if (!r) return go('#/');

  if (r.guest && state.user) return go('#/');
  if (!r.guest && !state.user) return go('#/login');

  app.replaceChildren(h('div', { class: 'boot' }, spinner()));
  const match = path.match(r.re);
  const ctx = { params: { id: match[1] }, query, state };
  let node;
  try {
    node = await r.view(ctx);
  } catch (e) {
    node = h('div', { class: 'page' }, h('div', { class: 'banner error' }, icon('alert'), h('div', {}, e.message || 'Não foi possível abrir esta página.')));
  }
  if (token !== routeToken) return;
  app.replaceChildren(r.guest ? node : shell(node, r.nav));
  window.scrollTo(0, 0);
}

async function boot() {
  setUnauthorizedHandler(() => {
    if (state.user) {
      state.user = null;
      toast('Sua sessão expirou. Entre de novo.', 'error');
      go('#/login');
    }
  });
  try {
    state.config = await api('/config');
  } catch (e) {
    app.replaceChildren(
      h('div', { class: 'boot' }, h('div', { class: 'card center' }, h('h2', {}, 'Não foi possível conectar'), h('p', { class: 'muted' }, e.message), h('button', { class: 'btn primary', onclick: () => location.reload() }, 'Tentar de novo')))
    );
    return;
  }
  try {
    state.user = (await api('/auth/me')).user;
  } catch {
    state.user = null;
  }
  window.addEventListener('hashchange', route);
  route();
}

boot();
