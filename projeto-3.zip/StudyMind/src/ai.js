import { config, aiConfigured } from './config.js';
import { AppError } from './errors.js';
import { extractJson } from './lib/json.js';

export const AI_NOT_CONFIGURED_MSG =
  'A IA ainda não foi configurada neste servidor. Falta definir a variável ANTHROPIC_API_KEY no arquivo .env e reiniciar o servidor (veja o README).';

// Chama a API da Anthropic (Claude). A chave fica só no servidor.
export async function askClaude({ system, messages, maxTokens = 2000 }) {
  if (!aiConfigured()) {
    throw new AppError(503, AI_NOT_CONFIGURED_MSG, 'AI_NOT_CONFIGURED');
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), config.ai.timeoutMs);
  let res;
  try {
    res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': config.ai.apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: config.ai.model,
        max_tokens: maxTokens,
        system,
        messages
      }),
      signal: ctrl.signal
    });
  } catch (e) {
    if (e && e.name === 'AbortError') {
      throw new AppError(504, 'A IA demorou demais para responder. Tente novamente.', 'AI_TIMEOUT');
    }
    throw new AppError(502, 'Não foi possível conectar ao serviço de IA. Verifique a conexão do servidor.', 'AI_UNREACHABLE');
  } finally {
    clearTimeout(timer);
  }

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const detalhe = data && data.error && data.error.message ? data.error.message : res.statusText;
    console.error(`[ia] erro ${res.status}: ${detalhe}`);
    if (res.status === 401 || res.status === 403) {
      throw new AppError(503, 'A chave da API de IA foi recusada. Confira o valor de ANTHROPIC_API_KEY no .env.', 'AI_BAD_KEY');
    }
    if (res.status === 404) {
      throw new AppError(503, 'O modelo de IA configurado (AI_MODEL) não foi encontrado. Confira o nome no .env.', 'AI_BAD_MODEL');
    }
    if (res.status === 429) {
      throw new AppError(429, 'O serviço de IA está com muitas requisições agora. Tente de novo em instantes.', 'AI_BUSY');
    }
    if (res.status === 400) {
      throw new AppError(400, 'A IA não aceitou este pedido (conteúdo ou imagem inválidos). Tente com outro conteúdo.', 'AI_REJECTED');
    }
    throw new AppError(502, 'O serviço de IA está indisponível no momento. Tente novamente.', 'AI_UNAVAILABLE');
  }

  const text = ((data && data.content) || [])
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('\n')
    .trim();
  if (!text) throw new AppError(502, 'A IA retornou uma resposta vazia. Tente novamente.', 'AI_EMPTY');
  return { text, truncated: data.stop_reason === 'max_tokens' };
}

// Pede um JSON à IA, valida e tenta de novo uma vez se vier fora do formato.
export async function askJson({ system, messages, maxTokens = 3000, validate }) {
  let lastError = null;
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    const msgs =
      tentativa === 0
        ? messages
        : [...messages, { role: 'user', content: 'Responda de novo, agora SOMENTE com o JSON válido e completo, sem texto antes ou depois.' }];
    const { text, truncated } = await askClaude({ system, messages: msgs, maxTokens });
    try {
      if (truncated) throw new Error('resposta cortada');
      return validate(extractJson(text));
    } catch (e) {
      lastError = e;
      console.error('[ia] formato inválido:', e.message);
    }
  }
  throw new AppError(502, 'A IA não retornou o conteúdo no formato esperado. Tente novamente.', 'AI_BAD_FORMAT');
}
