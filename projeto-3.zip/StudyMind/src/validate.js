import { AppError } from './errors.js';

const GENERIC = /^(Required|Invalid|Expected|String must|Number must|Array must|Unrecognized)/;

export function parse(schema, data) {
  const r = schema.safeParse(data ?? {});
  if (!r.success) {
    const issue = r.error.issues[0];
    const campo = issue.path.join('.') || 'dados';
    const msg = issue.message && !GENERIC.test(issue.message) ? issue.message : `Valor inválido em "${campo}".`;
    throw new AppError(400, msg, 'VALIDATION');
  }
  return r.data;
}
