import nodemailer from 'nodemailer';
import { config, emailConfigured } from './config.js';

let transporter = null;

function get() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.secure,
      auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined
    });
  }
  return transporter;
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export async function sendResetEmail(user, link) {
  if (!emailConfigured()) return false;
  await get().sendMail({
    from: config.smtp.from,
    to: user.email,
    subject: 'StudyMind AI - redefinição de senha',
    text: `Olá, ${user.name}!\n\nPara criar uma nova senha, abra o link abaixo (vale por 1 hora):\n${link}\n\nSe você não pediu isso, ignore este e-mail.`,
    html: `<p>Olá, ${esc(user.name)}!</p><p>Para criar uma nova senha, clique no link abaixo (vale por 1 hora):</p><p><a href="${esc(link)}">Redefinir minha senha</a></p><p>Se você não pediu isso, ignore este e-mail.</p>`
  });
  return true;
}
