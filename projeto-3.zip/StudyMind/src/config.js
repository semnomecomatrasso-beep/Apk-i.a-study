import 'dotenv/config';
import crypto from 'node:crypto';

const env = process.env;
const str = (v, d = '') => (v === undefined || v === '' ? d : String(v));
const num = (v, d) => {
  if (v === undefined || v === '') return d;
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const port = num(env.PORT, 3000);
const baseUrl = str(env.BASE_URL, `http://localhost:${port}`).replace(/\/+$/, '');

export const config = {
  env: str(env.NODE_ENV, 'development'),
  isProd: env.NODE_ENV === 'production',
  port,
  baseUrl,
  secure: baseUrl.startsWith('https://'),
  trustProxy: num(env.TRUST_PROXY, 0),
  timezone: str(env.TIMEZONE, 'America/Sao_Paulo'),
  jwtSecret: str(env.JWT_SECRET),
  dbPath: str(env.DB_PATH, './data/studymind.db'),
  ai: {
    apiKey: str(env.ANTHROPIC_API_KEY),
    model: str(env.AI_MODEL, 'claude-sonnet-5-5'),
    maxImageMb: num(env.AI_MAX_IMAGE_MB, 5),
    timeoutMs: num(env.AI_TIMEOUT_MS, 90000)
  },
  google: {
    clientId: str(env.GOOGLE_CLIENT_ID),
    clientSecret: str(env.GOOGLE_CLIENT_SECRET)
  },
  smtp: {
    host: str(env.SMTP_HOST),
    port: num(env.SMTP_PORT, 587),
    secure: env.SMTP_SECURE === 'true',
    user: str(env.SMTP_USER),
    pass: str(env.SMTP_PASS),
    from: str(env.SMTP_FROM)
  },
  stripe: {
    secretKey: str(env.STRIPE_SECRET_KEY),
    webhookSecret: str(env.STRIPE_WEBHOOK_SECRET),
    priceMonthly: str(env.STRIPE_PRICE_MONTHLY),
    priceYearly: str(env.STRIPE_PRICE_YEARLY)
  },
  prices: {
    currency: str(env.PRICE_CURRENCY_LABEL, 'R$'),
    monthly: str(env.PRICE_PREMIUM_MONTHLY),
    yearly: str(env.PRICE_PREMIUM_YEARLY)
  }
};

export const aiConfigured = () => Boolean(config.ai.apiKey);
export const googleConfigured = () => Boolean(config.google.clientId && config.google.clientSecret);
export const emailConfigured = () => Boolean(config.smtp.host && config.smtp.from);
export const billingConfigured = () =>
  Boolean(
    config.stripe.secretKey &&
      config.stripe.webhookSecret &&
      (config.stripe.priceMonthly || config.stripe.priceYearly)
  );

// Garante um segredo de sessão. Em produção ele é obrigatório.
export function ensureSecret() {
  if (config.jwtSecret && config.jwtSecret.length >= 32) return;
  if (config.isProd) {
    throw new Error(
      'JWT_SECRET ausente ou curto demais (mínimo 32 caracteres). Defina no .env antes de rodar em produção.'
    );
  }
  config.jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn(
    '[aviso] JWT_SECRET não definido: usando um segredo temporário. As sessões caem quando o servidor reinicia.'
  );
}
