import { db } from './db.js';
import { config } from './config.js';
import { AppError } from './errors.js';
import { TOOLS, TOOL_LABELS, limitFor } from './lib/plans.js';

export function today() {
  return new Date().toLocaleDateString('en-CA', { timeZone: config.timezone });
}

function used(userId, tool) {
  const row = db
    .prepare('SELECT count FROM usage WHERE user_id = ? AND day = ? AND tool = ?')
    .get(userId, today(), tool);
  return row ? row.count : 0;
}

export function assertCanUse(user, tool) {
  const limit = limitFor(user.plan, tool);
  if (used(user.id, tool) >= limit) {
    const extra = user.plan === 'premium' ? '' : ' Veja a página de planos para limites maiores.';
    throw new AppError(
      429,
      `Você atingiu o limite diário de ${limit} uso(s) de "${TOOL_LABELS[tool]}". O contador zera à meia-noite.${extra}`,
      'LIMIT_REACHED'
    );
  }
}

export function recordUse(userId, tool) {
  db.prepare(
    `INSERT INTO usage (user_id, day, tool, count) VALUES (?, ?, ?, 1)
     ON CONFLICT(user_id, day, tool) DO UPDATE SET count = count + 1`
  ).run(userId, today(), tool);
}

export function usageSummary(user) {
  const tools = {};
  for (const t of TOOLS) {
    tools[t] = { used: used(user.id, t), limit: limitFor(user.plan, t), label: TOOL_LABELS[t] };
  }
  return { day: today(), plan: user.plan, tools };
}
