import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config, ensureSecret, aiConfigured, googleConfigured, emailConfigured, billingConfigured } from './config.js';
import './db.js';
import { AppError } from './errors.js';
import api from './routes/index.js';
import { webhookHandler } from './routes/billing.js';

ensureSecret();

const app = express();
const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', config.trustProxy);

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'script-src': ["'self'"],
        'style-src': ["'self'", "'unsafe-inline'"],
        'img-src': ["'self'", 'data:', 'blob:'],
        'connect-src': ["'self'"],
        'upgrade-insecure-requests': config.secure ? [] : null
      }
    }
  })
);

// O Stripe precisa do corpo "cru" para conferir a assinatura
app.post('/api/billing/webhook', express.raw({ type: 'application/json', limit: '1mb' }), webhookHandler);

// Fotos de atividades chegam em base64: limite maior só nesta rota
app.use('/api/solve', express.json({ limit: '10mb' }));
app.use(express.json({ limit: '300kb' }));
app.use(cookieParser());

app.use(express.static(publicDir, { maxAge: config.isProd ? '1h' : 0 }));
app.use('/api', api);

// Tratamento de erros: sempre responde em JSON, sem expor detalhes internos
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err instanceof AppError) {
    return res.status(err.status).json({ error: err.message, code: err.code });
  }
  if (err && err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'O envio é grande demais. Use uma imagem ou texto menor.', code: 'TOO_LARGE' });
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Dados enviados em formato inválido.', code: 'BAD_JSON' });
  }
  console.error(err);
  res.status(500).json({ error: 'Erro interno. Tente novamente em instantes.', code: 'INTERNAL' });
});

app.listen(config.port, () => {
  const ok = (v) => (v ? 'configurado' : 'NÃO configurado');
  console.log(`\nStudyMind AI rodando em ${config.baseUrl} (porta ${config.port}, ${config.env})`);
  console.log(`  IA (ANTHROPIC_API_KEY): ${ok(aiConfigured())}`);
  console.log(`  E-mail (SMTP):          ${ok(emailConfigured())}`);
  console.log(`  Login com Google:       ${ok(googleConfigured())}`);
  console.log(`  Pagamentos (Stripe):    ${ok(billingConfigured())}\n`);
});
