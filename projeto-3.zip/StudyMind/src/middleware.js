import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { db } from './db.js';
import { AppError } from './errors.js';

export const COOKIE = 'sm_token';
const WEEK = 7 * 24 * 60 * 60 * 1000;

export function setSession(res, userId) {
  const token = jwt.sign({ sub: Number(userId) }, config.jwtSecret, { expiresIn: '7d' });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.secure,
    maxAge: WEEK,
    path: '/'
  });
}

export function clearSession(res) {
  res.clearCookie(COOKIE, { httpOnly: true, sameSite: 'lax', secure: config.secure, path: '/' });
}

export function loadUser(req, res, next) {
  const token = req.cookies && req.cookies[COOKIE];
  if (!token) return next();
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
    if (user) req.user = user;
  } catch {
    // token inválido ou expirado: segue como visitante
  }
  next();
}

export function requireAuth(req, res, next) {
  if (!req.user) return next(new AppError(401, 'Você precisa entrar na sua conta.', 'UNAUTHENTICATED'));
  next();
}

// Defesa contra CSRF: exige um cabeçalho que formulários de outros sites não conseguem enviar.
export function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-requested-with') !== 'StudyMind') {
    return next(new AppError(403, 'Requisição bloqueada por segurança. Recarregue a página.', 'CSRF'));
  }
  next();
}

const base = {
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) =>
    res.status(429).json({ error: 'Muitas tentativas em pouco tempo. Aguarde um pouco e tente de novo.', code: 'RATE_LIMIT' })
};

export const apiLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 600 });
export const authLimiter = rateLimit({ ...base, windowMs: 15 * 60 * 1000, limit: 20 });
export const aiLimiter = rateLimit({
  ...base,
  windowMs: 60 * 1000,
  limit: 15,
  keyGenerator: (req) => (req.user ? 'u' + req.user.id : req.ip)
});
