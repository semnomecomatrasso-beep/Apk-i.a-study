import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { askJson } from '../ai.js';
import { EXAM_SYSTEM } from '../prompts.js';
import { assertCanUse, recordUse } from '../usage.js';
import { safeJson, shuffle } from '../lib/json.js';

const router = Router();

const genSchema = z.object({
  subject: z.string().trim().min(2, 'Informe a matéria.').max(60, 'Matéria muito longa.'),
  topic: z.string().trim().min(2, 'Informe o assunto.').max(120, 'Assunto muito longo.'),
  difficulty: z.enum(['facil', 'medio', 'dificil'], { message: 'Escolha a dificuldade.' }),
  count: z.number({ message: 'Informe a quantidade de questões.' }).int().min(1, 'Mínimo de 1 questão.').max(20, 'Máximo de 20 questões.'),
  choices: z.number().int().min(3).max(5).default(4),
  level: z.string().trim().max(40).optional()
});

const examOut = z.object({
  titulo: z.string().min(1).max(150),
  questoes: z
    .array(
      z.object({
        enunciado: z.string().min(5),
        alternativas: z.array(z.string().min(1)).min(3).max(5),
        correta: z.number().int().min(0),
        explicacao: z.string().min(1)
      })
    )
    .min(1)
});

const DIFF = { facil: 'fácil', medio: 'média', dificil: 'difícil' };

router.post('/', asyncH(async (req, res) => {
  const d = parse(genSchema, req.body);
  const user = req.user;
  assertCanUse(user, 'exam');

  // evita repetir questões de provas anteriores do mesmo assunto
  const antigas = db
    .prepare('SELECT data FROM exams WHERE user_id = ? AND subject = ? AND topic = ? ORDER BY id DESC LIMIT 3')
    .all(user.id, d.subject, d.topic)
    .flatMap((r) => (safeJson(r.data, { questoes: [] }).questoes || []).map((q) => q.enunciado.slice(0, 80)))
    .slice(0, 15);

  const prompt = `Crie uma prova INÉDITA de ${d.subject}, assunto: ${d.topic}.
Dificuldade: ${DIFF[d.difficulty]}. Nível escolar: ${d.level || 'ensino médio'}.
Quantidade: exatamente ${d.count} questões de múltipla escolha, cada uma com exatamente ${d.choices} alternativas e UMA correta.
Varie os tipos de questão (conceito, aplicação, interpretação) e o contexto dos enunciados.
${antigas.length ? 'Não repita nem pareça com estas questões já feitas pelo estudante:\n- ' + antigas.join('\n- ') + '\n' : ''}Código de variação (para gerar algo diferente): ${crypto.randomBytes(4).toString('hex')}

Formato do JSON (o campo "correta" é o índice da alternativa certa, começando em 0):
{"titulo":"...","questoes":[{"enunciado":"...","alternativas":["...","..."],"correta":0,"explicacao":"explicação curta de por que a alternativa correta está certa e as outras não"}]}`;

  const exam = await askJson({
    system: EXAM_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
    maxTokens: Math.min(8000, 700 + d.count * 450),
    validate: (obj) => {
      const parsed = examOut.parse(obj);
      const questoes = parsed.questoes.slice(0, d.count).map((q) => {
        if (q.alternativas.length !== d.choices || q.correta >= q.alternativas.length) {
          throw new Error('questão fora do formato');
        }
        // embaralha as alternativas para a resposta certa não ficar sempre na mesma posição
        const certa = q.alternativas[q.correta];
        const alternativas = shuffle(q.alternativas);
        return { enunciado: q.enunciado, alternativas, correta: alternativas.indexOf(certa), explicacao: q.explicacao };
      });
      if (questoes.length < d.count) throw new Error('poucas questões');
      return { titulo: parsed.titulo, questoes };
    }
  });

  const id = Number(
    db
      .prepare('INSERT INTO exams (user_id, title, subject, topic, difficulty, data) VALUES (?, ?, ?, ?, ?, ?)')
      .run(user.id, exam.titulo, d.subject, d.topic, d.difficulty, JSON.stringify(exam)).lastInsertRowid
  );
  recordUse(user.id, 'exam');
  res.status(201).json({ exam: publicExam({ id, title: exam.titulo, subject: d.subject, topic: d.topic, difficulty: d.difficulty, data: JSON.stringify(exam) }) });
}));

function publicExam(row) {
  const data = safeJson(row.data, { questoes: [] });
  return {
    id: row.id,
    title: row.title,
    subject: row.subject,
    topic: row.topic,
    difficulty: row.difficulty,
    questions: data.questoes.map((q, i) => ({ n: i + 1, enunciado: q.enunciado, alternativas: q.alternativas }))
  };
}

router.get('/', (req, res) => {
  const rows = db
    .prepare('SELECT id, title, subject, topic, difficulty, data, created_at AS createdAt FROM exams WHERE user_id = ? ORDER BY id DESC LIMIT 50')
    .all(req.user.id);
  const stats = db
    .prepare('SELECT exam_id, COUNT(*) AS attempts, MAX(score * 1.0 / total) AS best FROM exam_attempts WHERE user_id = ? GROUP BY exam_id')
    .all(req.user.id);
  const byExam = new Map(stats.map((s) => [s.exam_id, s]));
  res.json({
    items: rows.map((r) => {
      const s = byExam.get(r.id);
      return {
        id: r.id,
        title: r.title,
        subject: r.subject,
        topic: r.topic,
        difficulty: r.difficulty,
        total: (safeJson(r.data, { questoes: [] }).questoes || []).length,
        attempts: s ? s.attempts : 0,
        bestPercent: s ? Math.round(s.best * 100) : null,
        createdAt: r.createdAt
      };
    })
  });
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM exams WHERE id = ? AND user_id = ?').get(Number(req.params.id), req.user.id);
  if (!row) throw new AppError(404, 'Prova não encontrada.', 'NOT_FOUND');
  const attempts = db
    .prepare('SELECT id, score, total, created_at AS createdAt FROM exam_attempts WHERE exam_id = ? ORDER BY id DESC LIMIT 20')
    .all(row.id);
  res.json({ exam: publicExam(row), attempts });
});

const submitSchema = z.object({
  answers: z.array(z.number().int().min(0).max(4).nullable()).min(1).max(20)
});

router.post('/:id/submit', asyncH(async (req, res) => {
  const row = db.prepare('SELECT * FROM exams WHERE id = ? AND user_id = ?').get(Number(req.params.id), req.user.id);
  if (!row) throw new AppError(404, 'Prova não encontrada.', 'NOT_FOUND');
  const { answers } = parse(submitSchema, req.body);
  const questoes = safeJson(row.data, { questoes: [] }).questoes;
  if (answers.length !== questoes.length) {
    throw new AppError(400, 'O número de respostas não bate com o número de questões.', 'VALIDATION');
  }
  let score = 0;
  const results = questoes.map((q, i) => {
    const escolhida = answers[i];
    const acertou = escolhida === q.correta;
    if (acertou) score++;
    return { n: i + 1, enunciado: q.enunciado, alternativas: q.alternativas, escolhida, correta: q.correta, acertou, explicacao: q.explicacao };
  });
  const total = questoes.length;
  db.prepare('INSERT INTO exam_attempts (exam_id, user_id, score, total, answers) VALUES (?, ?, ?, ?, ?)').run(
    row.id,
    req.user.id,
    score,
    total,
    JSON.stringify(answers)
  );
  res.json({
    score,
    total,
    percent: Math.round((score / total) * 100),
    nota: Math.round((score / total) * 100) / 10,
    results
  });
}));

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM exams WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
  if (!info.changes) throw new AppError(404, 'Prova não encontrada.', 'NOT_FOUND');
  res.json({ ok: true });
});

export default router;
