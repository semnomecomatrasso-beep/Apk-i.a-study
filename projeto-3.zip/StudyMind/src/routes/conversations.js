import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError } from '../errors.js';
import { parse } from '../validate.js';
import { safeJson } from '../lib/json.js';

const router = Router();
const kindSchema = z.object({ kind: z.enum(['chat', 'tutor']).default('chat') });

router.get('/', (req, res) => {
  const { kind } = parse(kindSchema, req.query);
  const rows = db
    .prepare('SELECT id, title, meta, updated_at FROM conversations WHERE user_id = ? AND kind = ? ORDER BY updated_at DESC, id DESC LIMIT 60')
    .all(req.user.id, kind);
  res.json({ items: rows.map((r) => ({ id: r.id, title: r.title, meta: safeJson(r.meta, {}), updatedAt: r.updated_at })) });
});

router.get('/:id', (req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(Number(req.params.id), req.user.id);
  if (!conv) throw new AppError(404, 'Conversa não encontrada.', 'NOT_FOUND');
  const messages = db
    .prepare('SELECT id, role, content, created_at AS createdAt FROM messages WHERE conversation_id = ? ORDER BY id')
    .all(conv.id);
  res.json({ id: conv.id, kind: conv.kind, title: conv.title, meta: safeJson(conv.meta, {}), messages });
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM conversations WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
  if (!info.changes) throw new AppError(404, 'Conversa não encontrada.', 'NOT_FOUND');
  res.json({ ok: true });
});

export default router;
