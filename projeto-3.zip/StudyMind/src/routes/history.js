import { Router } from 'express';
import { db } from '../db.js';
import { safeJson } from '../lib/json.js';

const router = Router();

router.get('/', (req, res) => {
  const uid = req.user.id;
  const limit = Math.min(Math.max(Number(req.query.limit) || 60, 1), 100);
  const items = [];

  for (const c of db.prepare('SELECT id, kind, title, updated_at FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 40').all(uid)) {
    items.push({ type: c.kind, id: c.id, title: c.title, subtitle: c.kind === 'tutor' ? 'Professor particular' : 'Chat inteligente', createdAt: c.updated_at });
  }
  for (const s of db.prepare('SELECT id, subject, answer, created_at FROM solutions WHERE user_id = ? ORDER BY id DESC LIMIT 40').all(uid)) {
    items.push({ type: 'solve', id: s.id, title: s.answer.replace(/[#*`]/g, '').replace(/\s+/g, ' ').trim().slice(0, 70) || 'Atividade resolvida', subtitle: s.subject ? 'Atividade · ' + s.subject : 'Atividade resolvida', createdAt: s.created_at });
  }
  for (const e of db.prepare('SELECT id, title, subject, topic, created_at, data FROM exams WHERE user_id = ? ORDER BY id DESC LIMIT 40').all(uid)) {
    const total = (safeJson(e.data, { questoes: [] }).questoes || []).length;
    items.push({ type: 'exam', id: e.id, title: e.title, subtitle: `Prova · ${e.subject} · ${total} questões`, createdAt: e.created_at });
  }
  for (const s of db.prepare('SELECT id, title, created_at FROM summaries WHERE user_id = ? ORDER BY id DESC LIMIT 40').all(uid)) {
    items.push({ type: 'summary', id: s.id, title: s.title, subtitle: 'Resumo', createdAt: s.created_at });
  }

  items.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  res.json({ items: items.slice(0, limit) });
});

export default router;
