import { Router } from 'express';
import { config, aiConfigured, googleConfigured, emailConfigured, billingConfigured } from '../config.js';
import { AppError } from '../errors.js';
import { apiLimiter, csrfGuard, loadUser, requireAuth, aiLimiter } from '../middleware.js';
import { TOOLS, TOOL_LABELS, limitsFor } from '../lib/plans.js';
import { usageSummary } from '../usage.js';
import authRouter from './auth.js';
import billingRouter from './billing.js';
import profileRouter from './profile.js';
import conversationsRouter from './conversations.js';
import chatRouter from './chat.js';
import tutorRouter from './tutor.js';
import solveRouter from './solve.js';
import examsRouter from './exams.js';
import summariesRouter from './summaries.js';
import historyRouter from './history.js';

const api = Router();

api.use(apiLimiter);
api.use(csrfGuard);
api.use(loadUser);

api.get('/health', (req, res) => res.json({ ok: true }));

api.get('/config', (req, res) => {
  res.json({
    appName: 'StudyMind AI',
    aiConfigured: aiConfigured(),
    googleLogin: googleConfigured(),
    emailConfigured: emailConfigured(),
    billingConfigured: billingConfigured(),
    isProd: config.isProd
  });
});

api.get('/plans', (req, res) => {
  const fmt = (v) => (v ? `${config.prices.currency} ${v}` : null);
  res.json({
    billingConfigured: billingConfigured(),
    billing: { monthly: Boolean(config.stripe.priceMonthly), yearly: Boolean(config.stripe.priceYearly) },
    tools: TOOLS.map((id) => ({ id, label: TOOL_LABELS[id] })),
    plans: [
      {
        id: 'free',
        name: 'Gratuito',
        price: `${config.prices.currency} 0`,
        limits: limitsFor('free'),
        features: ['Todas as ferramentas de IA', 'Histórico de conversas, atividades, provas e resumos', 'Limites diários menores']
      },
      {
        id: 'premium',
        name: 'Premium',
        prices: { monthly: fmt(config.prices.monthly), yearly: fmt(config.prices.yearly) },
        limits: limitsFor('premium'),
        features: ['Todas as ferramentas de IA', 'Histórico de conversas, atividades, provas e resumos', 'Limites diários bem maiores']
      }
    ]
  });
});

api.use('/auth', authRouter);
api.use('/billing', billingRouter);

api.use(requireAuth);
api.get('/usage', (req, res) => res.json(usageSummary(req.user)));
api.use('/profile', profileRouter);
api.use('/conversations', conversationsRouter);
api.use('/history', historyRouter);
api.post('/chat', aiLimiter);
api.use('/chat', chatRouter);
api.post('/tutor', aiLimiter);
api.use('/tutor', tutorRouter);
api.post('/solve', aiLimiter);
api.use('/solve', solveRouter);
api.post('/exams', aiLimiter);
api.post('/summaries', aiLimiter);
api.use('/exams', examsRouter);
api.use('/summaries', summariesRouter);

api.use((req, res, next) => next(new AppError(404, 'Rota não encontrada.', 'NOT_FOUND')));

export default api;
