import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { askClaude } from '../ai.js';
import { chatSystem } from '../prompts.js';
import { assertCanUse, recordUse } from '../usage.js';
import { loadHistory, saveTurn } from '../lib/conversations.js';

const router = Router();

const schema = z.object({
  conversationId: z.number().int().positive().optional(),
  message: z.string().trim().min(1, 'Digite uma mensagem.').max(4000, 'Mensagem muito longa (máximo 4000 caracteres).')
});

router.post('/', asyncH(async (req, res) => {
  const body = parse(schema, req.body);
  const user = req.user;
  assertCanUse(user, 'chat');

  let conv = null;
  if (body.conversationId) {
    conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ? AND kind = 'chat'").get(body.conversationId, user.id);
    if (!conv) throw new AppError(404, 'Conversa não encontrada.', 'NOT_FOUND');
  }
  const history = conv ? loadHistory(conv.id) : [];
  const { text } = await askClaude({
    system: chatSystem(user),
    messages: [...history, { role: 'user', content: body.message }],
    maxTokens: 1800
  });

  const title = body.message.replace(/\s+/g, ' ').slice(0, 60);
  const conversationId = saveTurn({ userId: user.id, kind: 'chat', conv, title, userText: body.message, reply: text });
  recordUse(user.id, 'chat');
  res.json({ conversationId, reply: text, title: conv ? conv.title : title });
}));

export default router;
