import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { askJson } from '../ai.js';
import { SUMMARY_SYSTEM } from '../prompts.js';
import { assertCanUse, recordUse } from '../usage.js';
import { safeJson } from '../lib/json.js';

const router = Router();

const schema = z.object({
  title: z.string().trim().max(120, 'Título muito longo.').optional(),
  text: z.string().trim().min(80, 'Cole um texto maior (mínimo de 80 caracteres) para resumir.').max(30000, 'Texto muito grande (máximo de 30.000 caracteres).')
});

const outSchema = z.object({
  titulo: z.string().min(1).max(150),
  resumo: z.string().min(20),
  pontos_importantes: z.array(z.string().min(1)).min(1).max(25),
  mapa_mental: z.object({
    centro: z.string().min(1),
    ramos: z
      .array(z.object({ nome: z.string().min(1), itens: z.array(z.string().min(1)).default([]) }))
      .min(1)
      .max(12)
  }),
  termos_chave: z.array(z.object({ termo: z.string().min(1), definicao: z.string().min(1) })).default([]),
  perguntas_revisao: z.array(z.string().min(1)).default([])
});

router.post('/', asyncH(async (req, res) => {
  const body = parse(schema, req.body);
  const user = req.user;
  assertCanUse(user, 'summary');

  const prompt = `Transforme o texto abaixo em material de estudo.
Gere: um título curto; um resumo organizado em parágrafos curtos; a lista dos pontos mais importantes; um mapa mental em formato de árvore (um tópico central e ramos com itens curtos); termos-chave com definição; e 3 a 5 perguntas de revisão.
Use apenas informações do texto.

Formato do JSON:
{"titulo":"...","resumo":"...","pontos_importantes":["..."],"mapa_mental":{"centro":"...","ramos":[{"nome":"...","itens":["..."]}]},"termos_chave":[{"termo":"...","definicao":"..."}],"perguntas_revisao":["..."]}

TEXTO:
"""
${body.text}
"""`;

  const data = await askJson({
    system: SUMMARY_SYSTEM,
    messages: [{ role: 'user', content: prompt }],
    maxTokens: 3500,
    validate: (obj) => outSchema.parse(obj)
  });

  const title = (body.title || data.titulo).slice(0, 120);
  const id = Number(
    db.prepare('INSERT INTO summaries (user_id, title, source_chars, data) VALUES (?, ?, ?, ?)').run(user.id, title, body.text.length, JSON.stringify(data)).lastInsertRowid
  );
  recordUse(user.id, 'summary');
  res.status(201).json({ id, title, data });
}));

router.get('/', (req, res) => {
  const rows = db
    .prepare('SELECT id, title, source_chars AS chars, created_at AS createdAt FROM summaries WHERE user_id = ? ORDER BY id DESC LIMIT 30')
    .all(req.user.id);
  res.json({ items: rows });
});

router.get('/:id', (req, res) => {
  const r = db.prepare('SELECT * FROM summaries WHERE id = ? AND user_id = ?').get(Number(req.params.id), req.user.id);
  if (!r) throw new AppError(404, 'Resumo não encontrado.', 'NOT_FOUND');
  res.json({ id: r.id, title: r.title, createdAt: r.created_at, data: safeJson(r.data, null) });
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM summaries WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
  if (!info.changes) throw new AppError(404, 'Resumo não encontrado.', 'NOT_FOUND');
  res.json({ ok: true });
});

export default router;
