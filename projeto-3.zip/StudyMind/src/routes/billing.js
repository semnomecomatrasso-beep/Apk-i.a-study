import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '../db.js';
import { config, billingConfigured } from '../config.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { requireAuth } from '../middleware.js';

const router = Router();

const NOT_CONFIGURED =
  'Os pagamentos ainda não foram configurados pelo administrador do site. Faltam STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET e pelo menos um STRIPE_PRICE_* no arquivo .env.';

async function stripe(path, params) {
  let res;
  try {
    res = await fetch('https://api.stripe.com/v1' + path, {
      method: 'POST',
      headers: {
        authorization: 'Bearer ' + config.stripe.secretKey,
        'content-type': 'application/x-www-form-urlencoded'
      },
      body: params
    });
  } catch {
    throw new AppError(502, 'Não foi possível falar com o provedor de pagamento agora.', 'BILLING_UNREACHABLE');
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    console.error('[stripe] erro', res.status, data && data.error && data.error.message);
    throw new AppError(502, 'O provedor de pagamento recusou o pedido. Avise o administrador.', 'BILLING_ERROR');
  }
  return data;
}

router.post('/checkout', requireAuth, asyncH(async (req, res) => {
  if (!billingConfigured()) throw new AppError(503, NOT_CONFIGURED, 'BILLING_NOT_CONFIGURED');
  const { interval } = parse(z.object({ interval: z.enum(['monthly', 'yearly']) }), req.body);
  const price = interval === 'monthly' ? config.stripe.priceMonthly : config.stripe.priceYearly;
  if (!price) throw new AppError(503, 'Esta opção de plano ainda não tem preço configurado no servidor.', 'BILLING_NOT_CONFIGURED');
  if (req.user.plan === 'premium') throw new AppError(409, 'Você já tem o plano Premium.', 'ALREADY_PREMIUM');

  const params = new URLSearchParams({
    mode: 'subscription',
    'line_items[0][price]': price,
    'line_items[0][quantity]': '1',
    success_url: `${config.baseUrl}/#/plans?status=success`,
    cancel_url: `${config.baseUrl}/#/plans?status=cancel`,
    client_reference_id: String(req.user.id),
    allow_promotion_codes: 'true'
  });
  if (req.user.stripe_customer) params.set('customer', req.user.stripe_customer);
  else params.set('customer_email', req.user.email);

  const session = await stripe('/checkout/sessions', params);
  res.json({ url: session.url });
}));

router.post('/portal', requireAuth, asyncH(async (req, res) => {
  if (!billingConfigured()) throw new AppError(503, NOT_CONFIGURED, 'BILLING_NOT_CONFIGURED');
  if (!req.user.stripe_customer) throw new AppError(400, 'Você ainda não tem uma assinatura para gerenciar.', 'NO_SUBSCRIPTION');
  const session = await stripe(
    '/billing_portal/sessions',
    new URLSearchParams({ customer: req.user.stripe_customer, return_url: `${config.baseUrl}/#/plans` })
  );
  res.json({ url: session.url });
}));

function signatureOk(raw, header, secret) {
  if (!header) return false;
  const pairs = header.split(',').map((p) => p.split('='));
  const t = (pairs.find((p) => p[0] === 't') || [])[1];
  const sigs = pairs.filter((p) => p[0] === 'v1').map((p) => p[1]);
  if (!t || !sigs.length) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > 300) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${t}.${raw.toString('utf8')}`).digest('hex');
  return sigs.some((s) => s && s.length === expected.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected)));
}

// Recebe os avisos do Stripe (rota com corpo "raw", montada no server.js)
export function webhookHandler(req, res) {
  if (!billingConfigured()) return res.status(503).json({ error: NOT_CONFIGURED });
  const raw = req.body;
  if (!Buffer.isBuffer(raw) || !signatureOk(raw, req.get('stripe-signature'), config.stripe.webhookSecret)) {
    return res.status(400).json({ error: 'Assinatura inválida.' });
  }
  let event;
  try {
    event = JSON.parse(raw.toString('utf8'));
  } catch {
    return res.status(400).json({ error: 'Corpo inválido.' });
  }
  const obj = event.data && event.data.object ? event.data.object : {};
  try {
    if (event.type === 'checkout.session.completed' && obj.client_reference_id) {
      db.prepare("UPDATE users SET plan = 'premium', stripe_customer = ?, stripe_subscription = ? WHERE id = ?").run(
        obj.customer || null,
        obj.subscription || null,
        Number(obj.client_reference_id)
      );
    } else if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
      const ativa = event.type === 'customer.subscription.updated' && ['active', 'trialing', 'past_due'].includes(obj.status);
      db.prepare('UPDATE users SET plan = ? WHERE stripe_subscription = ?').run(ativa ? 'premium' : 'free', obj.id);
    }
  } catch (e) {
    console.error('[stripe] falha ao processar evento:', e.message);
    return res.status(500).json({ error: 'Falha ao processar.' });
  }
  res.json({ received: true });
}

export default router;
