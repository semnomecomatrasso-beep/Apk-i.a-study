import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { config } from '../config.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { askClaude } from '../ai.js';
import { solveSystem } from '../prompts.js';
import { assertCanUse, recordUse } from '../usage.js';

const router = Router();

const schema = z.object({
  image: z.object({
    mediaType: z.enum(['image/jpeg', 'image/png', 'image/webp', 'image/gif'], { message: 'Formato de imagem não suportado. Use JPG, PNG, WebP ou GIF.' }),
    data: z.string().min(100, 'Imagem inválida.')
  }),
  subject: z.string().trim().max(60).optional(),
  note: z.string().trim().max(1000, 'A observação pode ter até 1000 caracteres.').optional()
});

router.post('/', asyncH(async (req, res) => {
  const body = parse(schema, req.body);
  const user = req.user;
  assertCanUse(user, 'solve');

  const b64 = body.image.data.replace(/^data:[^,]+,/, '');
  if (!/^[A-Za-z0-9+/=\r\n]+$/.test(b64)) throw new AppError(400, 'Imagem inválida.', 'VALIDATION');
  const bytes = Math.floor((b64.length * 3) / 4);
  if (bytes > config.ai.maxImageMb * 1024 * 1024) {
    throw new AppError(413, `A imagem é grande demais (máximo ${config.ai.maxImageMb} MB).`, 'TOO_LARGE');
  }

  let instrucao = 'Resolva a atividade da imagem seguindo a estrutura combinada.';
  if (body.subject) instrucao += ` Matéria: ${body.subject}.`;
  if (body.note) instrucao += ` Observação do estudante: ${body.note}`;

  const { text } = await askClaude({
    system: solveSystem(user),
    messages: [
      {
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: body.image.mediaType, data: b64 } },
          { type: 'text', text: instrucao }
        ]
      }
    ],
    maxTokens: 3000
  });

  const id = Number(
    db.prepare('INSERT INTO solutions (user_id, subject, note, answer) VALUES (?, ?, ?, ?)').run(user.id, body.subject || '', body.note || '', text).lastInsertRowid
  );
  recordUse(user.id, 'solve');
  res.json({ id, answer: text });
}));

router.get('/', (req, res) => {
  const rows = db
    .prepare('SELECT id, subject, note, answer, created_at AS createdAt FROM solutions WHERE user_id = ? ORDER BY id DESC LIMIT 20')
    .all(req.user.id);
  res.json({ items: rows.map((r) => ({ id: r.id, subject: r.subject, createdAt: r.createdAt, preview: r.answer.replace(/[#*`]/g, '').slice(0, 90) })) });
});

router.get('/:id', (req, res) => {
  const r = db
    .prepare('SELECT id, subject, note, answer, created_at AS createdAt FROM solutions WHERE id = ? AND user_id = ?')
    .get(Number(req.params.id), req.user.id);
  if (!r) throw new AppError(404, 'Atividade não encontrada.', 'NOT_FOUND');
  res.json(r);
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM solutions WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
  if (!info.changes) throw new AppError(404, 'Atividade não encontrada.', 'NOT_FOUND');
  res.json({ ok: true });
});

export default router;
