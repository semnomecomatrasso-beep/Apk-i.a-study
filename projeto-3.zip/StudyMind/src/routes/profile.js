import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { publicUser } from '../lib/user.js';
import { clearSession } from '../middleware.js';

const router = Router();

const profileSchema = z.object({
  name: z.string().trim().min(2, 'Digite seu nome (mínimo 2 letras).').max(60, 'Nome muito longo.'),
  schoolLevel: z.string().trim().max(40, 'Nível escolar muito longo.').default(''),
  favoriteSubjects: z.array(z.string().trim().min(1).max(40)).max(12, 'Escolha no máximo 12 matérias.').default([])
});
const passwordSchema = z.object({
  current: z.string().max(100).optional(),
  next: z.string().min(8, 'A nova senha precisa ter pelo menos 8 caracteres.').max(100)
});
const deleteSchema = z.object({ password: z.string().max(100).optional() });

router.put('/', asyncH(async (req, res) => {
  const d = parse(profileSchema, req.body);
  const subjects = [...new Set(d.favoriteSubjects)];
  db.prepare('UPDATE users SET name = ?, school_level = ?, favorite_subjects = ? WHERE id = ?').run(
    d.name,
    d.schoolLevel,
    JSON.stringify(subjects),
    req.user.id
  );
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
}));

router.post('/password', asyncH(async (req, res) => {
  const d = parse(passwordSchema, req.body);
  if (req.user.password_hash) {
    if (!d.current || !(await bcrypt.compare(d.current, req.user.password_hash))) {
      throw new AppError(400, 'A senha atual está incorreta.', 'BAD_PASSWORD');
    }
  }
  const hash = await bcrypt.hash(d.next, 12);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, req.user.id);
  res.json({ ok: true });
}));

router.delete('/', asyncH(async (req, res) => {
  const d = parse(deleteSchema, req.body);
  if (req.user.password_hash) {
    if (!d.password || !(await bcrypt.compare(d.password, req.user.password_hash))) {
      throw new AppError(400, 'Senha incorreta. A conta não foi apagada.', 'BAD_PASSWORD');
    }
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(req.user.id);
  clearSession(res);
  res.json({ ok: true });
}));

export default router;
