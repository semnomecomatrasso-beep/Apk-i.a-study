import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '../db.js';
import { config, googleConfigured, emailConfigured } from '../config.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { publicUser } from '../lib/user.js';
import { authLimiter, setSession, clearSession, requireAuth } from '../middleware.js';
import { sendResetEmail } from '../mailer.js';

const router = Router();

const registerSchema = z.object({
  name: z.string().trim().min(2, 'Digite seu nome (mínimo 2 letras).').max(60, 'Nome muito longo.'),
  email: z.string().trim().toLowerCase().email('E-mail inválido.').max(120, 'E-mail muito longo.'),
  password: z.string().min(8, 'A senha precisa ter pelo menos 8 caracteres.').max(100, 'Senha muito longa.')
});
const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email('E-mail inválido.'),
  password: z.string().min(1, 'Digite sua senha.').max(100)
});
const forgotSchema = z.object({ email: z.string().trim().toLowerCase().email('E-mail inválido.') });
const resetSchema = z.object({
  token: z.string().min(20, 'Link inválido.').max(200),
  password: z.string().min(8, 'A senha precisa ter pelo menos 8 caracteres.').max(100)
});

// Usado para gastar o mesmo tempo mesmo quando o e-mail não existe
const DUMMY_HASH = bcrypt.hashSync('senha-falsa-para-igualar-o-tempo', 12);
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

router.post('/register', authLimiter, asyncH(async (req, res) => {
  const { name, email, password } = parse(registerSchema, req.body);
  if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
    throw new AppError(409, 'Este e-mail já está cadastrado. Tente entrar.', 'EMAIL_TAKEN');
  }
  const hash = await bcrypt.hash(password, 12);
  let id;
  try {
    id = Number(db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)').run(name, email, hash).lastInsertRowid);
  } catch (e) {
    if (String(e.code).startsWith('SQLITE_CONSTRAINT')) {
      throw new AppError(409, 'Este e-mail já está cadastrado. Tente entrar.', 'EMAIL_TAKEN');
    }
    throw e;
  }
  setSession(res, id);
  res.status(201).json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) });
}));

router.post('/login', authLimiter, asyncH(async (req, res) => {
  const { email, password } = parse(loginSchema, req.body);
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const ok = await bcrypt.compare(password, user && user.password_hash ? user.password_hash : DUMMY_HASH);
  if (!user || !user.password_hash || !ok) {
    throw new AppError(401, 'E-mail ou senha incorretos.', 'BAD_CREDENTIALS');
  }
  setSession(res, user.id);
  res.json({ user: publicUser(user) });
}));

router.post('/logout', (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

router.post('/forgot', authLimiter, asyncH(async (req, res) => {
  const { email } = parse(forgotSchema, req.body);
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const msg = 'Se este e-mail estiver cadastrado, enviamos as instruções para criar uma nova senha.';

  if (!emailConfigured()) {
    if (config.isProd) {
      throw new AppError(
        503,
        'O envio de e-mails ainda não foi configurado neste servidor. Falta definir SMTP_HOST e SMTP_FROM (e usuário/senha, se o provedor pedir) no arquivo .env.',
        'EMAIL_NOT_CONFIGURED'
      );
    }
    if (user) {
      const link = createResetLink(user.id);
      console.log(`\n[recuperação de senha] E-mail não configurado. Link para ${user.email}:\n${link}\n`);
    }
    return res.json({
      ok: true,
      message: msg + ' (Modo desenvolvimento: o e-mail não está configurado, então o link foi impresso no console do servidor.)'
    });
  }

  if (user) {
    try {
      await sendResetEmail(user, createResetLink(user.id));
    } catch (e) {
      console.error('[e-mail] falha ao enviar:', e.message);
      throw new AppError(502, 'Não foi possível enviar o e-mail agora. Tente novamente mais tarde.', 'EMAIL_FAILED');
    }
  }
  res.json({ ok: true, message: msg });
}));

function createResetLink(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?').run(userId);
  db.prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)').run(
    userId,
    sha256(token),
    Date.now() + 60 * 60 * 1000
  );
  return `${config.baseUrl}/#/reset?token=${token}`;
}

router.post('/reset', authLimiter, asyncH(async (req, res) => {
  const { token, password } = parse(resetSchema, req.body);
  const row = db
    .prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > ?')
    .get(sha256(token), Date.now());
  if (!row) throw new AppError(400, 'Este link expirou ou já foi usado. Peça um novo.', 'BAD_RESET_TOKEN');
  const hash = await bcrypt.hash(password, 12);
  db.transaction(() => {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, row.user_id);
    db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?').run(row.user_id);
  })();
  res.json({ ok: true, message: 'Senha alterada! Agora você já pode entrar.' });
}));

// ---------- Login com Google (só funciona se GOOGLE_CLIENT_ID/SECRET estiverem no .env) ----------

const STATE_COOKIE = 'sm_oauth_state';
const redirectUri = () => `${config.baseUrl}/api/auth/google/callback`;

router.get('/google', (req, res) => {
  if (!googleConfigured()) return res.redirect('/#/login?error=google_not_configured');
  const state = crypto.randomBytes(16).toString('hex');
  res.cookie(STATE_COOKIE, state, { httpOnly: true, sameSite: 'lax', secure: config.secure, maxAge: 10 * 60 * 1000, path: '/' });
  const q = new URLSearchParams({
    client_id: config.google.clientId,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: 'openid email profile',
    state,
    prompt: 'select_account'
  });
  res.redirect('https://accounts.google.com/o/oauth2/v2/auth?' + q.toString());
});

router.get('/google/callback', asyncH(async (req, res) => {
  const fail = () => res.redirect('/#/login?error=google');
  if (!googleConfigured()) return res.redirect('/#/login?error=google_not_configured');
  const { code, state } = req.query;
  if (!code || !state || state !== req.cookies[STATE_COOKIE]) return fail();
  res.clearCookie(STATE_COOKIE, { path: '/' });
  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code: String(code),
        client_id: config.google.clientId,
        client_secret: config.google.clientSecret,
        redirect_uri: redirectUri(),
        grant_type: 'authorization_code'
      })
    });
    const tokens = await tokenRes.json();
    if (!tokenRes.ok || !tokens.access_token) return fail();
    const infoRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers: { authorization: 'Bearer ' + tokens.access_token }
    });
    const info = await infoRes.json();
    if (!infoRes.ok || !info.sub || !info.email || info.email_verified === false) return fail();

    const email = String(info.email).toLowerCase();
    let user = db.prepare('SELECT * FROM users WHERE google_id = ?').get(info.sub);
    if (!user) {
      user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
      if (user) {
        db.prepare('UPDATE users SET google_id = ? WHERE id = ?').run(info.sub, user.id);
      } else {
        const name = String(info.name || email.split('@')[0]).slice(0, 60);
        const id = Number(db.prepare('INSERT INTO users (name, email, google_id) VALUES (?, ?, ?)').run(name, email, info.sub).lastInsertRowid);
        user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
      }
    }
    setSession(res, user.id);
    res.redirect('/#/');
  } catch (e) {
    console.error('[google] falha no login:', e.message);
    fail();
  }
}));

export default router;
