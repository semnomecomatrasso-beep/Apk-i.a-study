import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db.js';
import { AppError, asyncH } from '../errors.js';
import { parse } from '../validate.js';
import { askClaude } from '../ai.js';
import { tutorSystem } from '../prompts.js';
import { assertCanUse, recordUse } from '../usage.js';
import { loadHistory, saveTurn } from '../lib/conversations.js';
import { safeJson } from '../lib/json.js';

const router = Router();

const schema = z.object({
  conversationId: z.number().int().positive().optional(),
  topic: z.string().trim().min(2, 'Informe o assunto da aula.').max(120, 'Assunto muito longo.').optional(),
  level: z.enum(['iniciante', 'intermediario', 'avancado']).default('intermediario'),
  style: z.enum(['simples', 'analogias', 'passo_a_passo', 'dia_a_dia', 'exercicios']).default('simples'),
  message: z.string().trim().min(1).max(4000, 'Mensagem muito longa (máximo 4000 caracteres).').optional()
});

router.post('/', asyncH(async (req, res) => {
  const body = parse(schema, req.body);
  const user = req.user;
  assertCanUse(user, 'tutor');

  let conv = null;
  let meta;
  let userText;
  if (body.conversationId) {
    conv = db.prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ? AND kind = 'tutor'").get(body.conversationId, user.id);
    if (!conv) throw new AppError(404, 'Aula não encontrada.', 'NOT_FOUND');
    if (!body.message) throw new AppError(400, 'Digite uma mensagem.', 'VALIDATION');
    const old = safeJson(conv.meta, {});
    meta = { topic: old.topic || 'Estudos', level: body.level, style: body.style };
    userText = body.message;
  } else {
    if (!body.topic) throw new AppError(400, 'Informe o assunto da aula.', 'VALIDATION');
    meta = { topic: body.topic, level: body.level, style: body.style };
    userText = body.message || `Quero aprender sobre: ${body.topic}.`;
  }

  const history = conv ? loadHistory(conv.id) : [];
  const { text } = await askClaude({
    system: tutorSystem(user, meta),
    messages: [...history, { role: 'user', content: userText }],
    maxTokens: 2000
  });

  const title = ('Aula: ' + meta.topic).slice(0, 60);
  const conversationId = saveTurn({ userId: user.id, kind: 'tutor', conv, title, meta, userText, reply: text });
  recordUse(user.id, 'tutor');
  res.json({ conversationId, reply: text, title: conv ? conv.title : title, meta });
}));

export default router;
