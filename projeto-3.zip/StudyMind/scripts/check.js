// Confere a sintaxe de todos os arquivos .js do projeto (sem rodar o servidor).
import { spawnSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dirs = ['src', 'public/js', 'scripts', 'test'];
const files = [];

function walk(dir) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) walk(full);
    else if (name.endsWith('.js')) files.push(full);
  }
}
for (const d of dirs) walk(join(root, d));

let falhas = 0;
for (const f of files) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) {
    falhas++;
    console.error('ERRO em ' + f + '\n' + r.stderr);
  }
}
console.log(files.length + ' arquivos verificados, ' + falhas + ' com erro.');
process.exit(falhas ? 1 : 0);
