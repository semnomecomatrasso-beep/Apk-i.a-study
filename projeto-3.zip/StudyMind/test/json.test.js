import test from 'node:test';
import assert from 'node:assert/strict';
import { extractJson, safeJson, shuffle } from '../src/lib/json.js';

test('extractJson lê JSON puro', () => {
  assert.deepEqual(extractJson('{"a":1}'), { a: 1 });
});

test('extractJson lê JSON dentro de cerca de código', () => {
  assert.deepEqual(extractJson('Aqui está:\n```json\n{"a":[1,2]}\n```'), { a: [1, 2] });
});

test('extractJson recorta texto antes e depois do JSON', () => {
  assert.deepEqual(extractJson('Claro! {"ok":true} Espero ter ajudado.'), { ok: true });
});

test('extractJson falha com texto sem JSON', () => {
  assert.throws(() => extractJson('sem json aqui'));
  assert.throws(() => extractJson(''));
});

test('safeJson usa o valor padrão em caso de erro', () => {
  assert.deepEqual(safeJson('{ruim', []), []);
  assert.deepEqual(safeJson('[1]', []), [1]);
});

test('shuffle mantém os mesmos elementos e não altera o original', () => {
  const original = [1, 2, 3, 4, 5];
  const r = shuffle(original);
  assert.deepEqual(original, [1, 2, 3, 4, 5]);
  assert.deepEqual(r.slice().sort(), [1, 2, 3, 4, 5]);
});
