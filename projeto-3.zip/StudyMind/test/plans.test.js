import test from 'node:test';
import assert from 'node:assert/strict';
import { limitFor, limitsFor, TOOLS } from '../src/lib/plans.js';

test('limites padrão: premium é maior que gratuito em todas as ferramentas', () => {
  for (const t of TOOLS) {
    assert.ok(limitFor('premium', t, {}) > limitFor('free', t, {}), t);
  }
});

test('plano desconhecido usa os limites do gratuito', () => {
  assert.equal(limitFor('qualquer', 'chat', {}), limitFor('free', 'chat', {}));
});

test('variáveis de ambiente trocam o limite', () => {
  assert.equal(limitFor('free', 'chat', { LIMIT_FREE_CHAT: '7' }), 7);
  assert.equal(limitFor('premium', 'exam', { LIMIT_PREMIUM_EXAM: '0' }), 0);
});

test('valores inválidos no ambiente são ignorados', () => {
  assert.equal(limitFor('free', 'chat', { LIMIT_FREE_CHAT: 'abc' }), limitFor('free', 'chat', {}));
  assert.equal(limitFor('free', 'chat', { LIMIT_FREE_CHAT: '-3' }), limitFor('free', 'chat', {}));
});

test('limitsFor devolve todas as ferramentas', () => {
  assert.deepEqual(Object.keys(limitsFor('free', {})).sort(), [...TOOLS].sort());
});
